using Blindspot.Core.Domain;

namespace Blindspot.Execution;

/// <summary>
/// A virtual execution backend that emulates PLC scan cycles and enforces simple actuation/rate limits.
/// In real deployments, this adapter can be replaced with vendor simulators or soft-PLC environments.
/// The paper describes vPLC execution as a software replica used for scalable screening (Sec 7.3). fileciteturn3file0L16-L27
/// </summary>
public sealed class VirtualPlcBackend : IPlcExecutionBackend
{
    public ExecutionResult Execute(ExecutionRequest req)
    {
        var tpl = req.Template;
        var step = req.StepSec;
        var horizon = tpl.HorizonSec;

        // Initial state from scenario defaults
        var state = ScenarioDefaults(req.ScenarioName);

        var points = new List<TracePoint>();
        var startTs = DateTimeOffset.UtcNow;

        bool alarm = false;
        DateTimeOffset? detectTs = null;

        for (double t = 0; t <= horizon; t += step)
        {
            // Apply manipulation if trigger satisfied and within duration.
            if (!alarm && tpl.Trigger.Evaluate(state) && t >= tpl.Duration.StartSec && t <= tpl.Duration.EndSec)
            {
                foreach (var kv in tpl.DeltaByVar)
                {
                    state.TryGetValue(kv.Key, out var cur);
                    // bounded incremental manipulations
                    state[kv.Key] = cur + kv.Value * (step / Math.Max(0.1, (tpl.Duration.EndSec - tpl.Duration.StartSec)));
                }
            }

            // Update plant dynamics (scenario-specific)
            StepDynamics(req.ScenarioName, state, step);

            // Enforce safety constraints: if any Safety layer condition holds, raise alarm and freeze "remote"
            foreach (var c in req.Mcm.Constraints.Where(x => x.Layer == ConstraintLayer.Safety))
            {
                if (c.When.Variable == "TRUE") continue;
                if (c.When.Evaluate(state))
                {
                    alarm = true;
                    detectTs ??= startTs.AddSeconds(t);
                    // apply safety action
                    ApplyEnforcement(state, c, step);
                }
            }

            // Apply control/operator constraints as rate limits or clamps
            foreach (var c in req.Mcm.Constraints.Where(x => x.Layer != ConstraintLayer.Safety))
            {
                if (c.When.Variable != "TRUE" && !c.When.Evaluate(state)) continue;
                ApplyEnforcement(state, c, step);
            }

            var flags = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase) { ["alarm"] = alarm };
            points.Add(new TracePoint(startTs.AddSeconds(t), t, new Dictionary<string, double>(state, StringComparer.OrdinalIgnoreCase), flags));
        }

        return new ExecutionResult(new ExecutionTrace(req.RunId, points), detectTs, alarm ? "Alarm observed during execution." : null);
    }

    private static void ApplyEnforcement(Dictionary<string, double> state, Constraint c, double step)
    {
        var act = c.Then;
        state.TryGetValue(act.TargetVariable, out var cur);

        switch (act.Kind)
        {
            case ActionKind.Clamp:
                // clamp to at most value (conservative)
                state[act.TargetVariable] = Math.Min(cur, act.Value);
                break;

            case ActionKind.SetDiscrete:
                state[act.TargetVariable] = act.Value;
                break;

            case ActionKind.RateLimit:
                if (act.MaxRatePerSec is null) return;
                // store previous value in a hidden key
                var prevKey = $"__prev__{act.TargetVariable}";
                state.TryGetValue(prevKey, out var prev);
                if (prev == 0 && !state.ContainsKey(prevKey)) prev = cur;

                var maxDelta = act.MaxRatePerSec.Value * step;
                var delta = cur - prev;
                if (Math.Abs(delta) > maxDelta)
                    cur = prev + Math.Sign(delta) * maxDelta;

                state[act.TargetVariable] = cur;
                state[prevKey] = cur;
                break;
        }
    }

    private static Dictionary<string, double> ScenarioDefaults(string name)
    {
        // Simple defaults for built-in sample scenarios.
        return name.ToLowerInvariant() switch
        {
            "water" => new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase)
            {
                ["Level"] = 65.0,
                ["Inflow"] = 50.0,
                ["Valve"] = 50.0,
                ["Pump"] = 1.0
            },
            "chemical" => new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase)
            {
                ["ReactorTemp"] = 80.0,
                ["ReactorPressure"] = 1.2,
                ["Feed"] = 50.0,
                ["Coolant"] = 50.0,
                ["Vent"] = 20.0,
                ["Neutralizer"] = 100.0
            },
            _ => new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase)
            {
                ["Distance"] = 80.0,
                ["SpeedA"] = 50.0,
                ["SpeedB"] = 50.0
            }
        };
    }

    private static void StepDynamics(string name, Dictionary<string, double> s, double step)
    {
        switch (name.ToLowerInvariant())
        {
            case "water":
                // Level increases with inflow, decreases with valve and pump.
                var inflow = s["Inflow"];
                var valve = s["Valve"];
                var pump = s["Pump"];
                var dL = (0.02 * inflow - 0.018 * valve * pump) * step;
                s["Level"] = Math.Clamp(s["Level"] + dL, 0, 100);
                break;

            case "chemical":
                var feed = s["Feed"];
                var coolant = s["Coolant"];
                var vent = s["Vent"];
                // temp rises with feed, decreases with coolant
                s["ReactorTemp"] = s["ReactorTemp"] + (0.03 * feed - 0.04 * coolant) * step;
                // pressure rises with feed, decreases with vent
                s["ReactorPressure"] = Math.Max(0.0, s["ReactorPressure"] + (0.002 * feed - 0.003 * vent) * step);
                // neutralizer consumed by venting (proxy for scrubber load)
                s["Neutralizer"] = Math.Max(0.0, s["Neutralizer"] - 0.05 * vent * step);
                break;

            default:
                // manufacturing: distance decreases with combined speeds
                var speedA = s["SpeedA"];
                var speedB = s["SpeedB"];
                s["Distance"] = Math.Max(0.0, s["Distance"] - 0.01 * (speedA + speedB) * step);
                break;
        }
    }
}
