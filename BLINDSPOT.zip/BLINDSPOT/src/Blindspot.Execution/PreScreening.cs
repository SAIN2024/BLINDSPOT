using Blindspot.Core.Domain;

namespace Blindspot.Execution;

public sealed class PreScreening
{
    /// <summary>
    /// Implements the "preliminary feasibility screening" after virtual execution:
    /// discard executions that:
    ///  (i) terminate before any documented recovery action is activated,
    ///  (ii) require manipulations exceeding bounds,
    ///  (iii) violate constraint semantics.
    /// (Paper Sec 7.3). fileciteturn3file0L53-L58
    /// </summary>
    public bool Accept(ExecutionTrace trace, MultiLayerConstraintModel mcm, out string reason)
    {
        reason = "";

        // (i) Require at least one alarm flag
        if (!trace.Points.Any(p => p.Flags is not null && p.Flags.TryGetValue("alarm", out var a) && a))
        {
            reason = "No alarm detected; recovery procedures not engaged.";
            return false;
        }

        // (iii) Constraint semantics: check extreme saturation (simple)
        foreach (var p in trace.Points)
        {
            if (p.Values.TryGetValue("Level", out var level) && (level < -1e-6 || level > 100 + 1e-6))
            {
                reason = "State out of bounds (Level).";
                return false;
            }
        }

        return true;
    }
}
