using Blindspot.Core.Domain;

namespace Blindspot.Execution;

public sealed record ExecutionRequest(
    string RunId,
    IncidentTemplate Template,
    MultiLayerConstraintModel Mcm,
    string ScenarioName,
    double StepSec = 0.2
);

public sealed record ExecutionResult(
    ExecutionTrace Trace,
    DateTimeOffset? DetectionTime,
    string? Notes
);

public interface IPlcExecutionBackend
{
    ExecutionResult Execute(ExecutionRequest req);
}
