using Blindspot.Core.Interfaces;
using Blindspot.Core.Models;
using Blindspot.Core.Utils;

namespace Blindspot.Execution;

/// <summary>
/// Mock "vPLC" executor:
/// - baseline trace acts as a surrogate simulator
/// - applies template deltas over [start,end] if trigger holds
/// - simple coupling dynamics to create meaningful changes
/// - detects constraint boundary reach using simple comparisons
/// </summary>
public sealed class MockPlcExecutor : IPlcExecutor
{
    public Task<ExecutionTrace> ExecuteAsync(
        MultiLayerConstraintModel mcm,
        IncidentTemplate template,
        IReadOnlyList<TracePoint> baselineTrace,
        CancellationToken ct)
    {
        if (baselineTrace.Count == 0)
            throw new InvalidOperationException("Baseline trace is empty.");

        var t0 = baselineTrace[0].Ts;
        var start = t0 + template.Timing.StartOffset;
        var end = t0 + template.Timing.EndOffset;
        var horizonEnd = t0 + template.ObservationHorizon;

        var points = new List<TracePoint>();
        foreach (var p in baselineTrace)
        {
            if (p.Ts < t0 || p.Ts > horizonEnd) continue;

            var dict = new Dictionary<string, double>(p.Vars, StringComparer.OrdinalIgnoreCase);

            var triggerOk = Expr.TryEvalTrigger(template.TriggerCondition, dict);
            if (triggerOk && p.Ts >= start && p.Ts <= end)
            {
                foreach (var v in template.Variables)
                {
                    if (dict.TryGetValue(v, out var val) && template.Delta.TryGetValue(v, out var d))
                        dict[v] = val + d;
                }
            }

            // simplistic process coupling
            if (dict.TryGetValue("Inflow", out var inflow) && dict.TryGetValue("Level", out var level))
                dict["Level"] = level + 0.02 * inflow;

            if (dict.TryGetValue("Heater", out var heater) && dict.TryGetValue("Pressure", out var pres))
                dict["Pressure"] = pres + 0.03 * heater;

            points.Add(new TracePoint(p.Ts, dict));
        }

        var violations = new List<(string ConstraintId, DateTime Ts)>();
        DateTime? firstAlarm = null;

        foreach (var p in points)
        {
            foreach (var c in mcm.Constraints.Values)
            {
                var parsed = Expr.TryParseSimpleComparison(c.When.Expr);
                if (parsed is null) continue;

                var (varName, op, boundary) = parsed.Value;
                if (!p.Vars.TryGetValue(varName, out var val)) continue;

                bool boundaryReached = op switch
                {
                    ">" or ">=" => val >= boundary,
                    "<" or "<=" => val <= boundary,
                    _ => false
                };

                if (boundaryReached)
                {
                    violations.Add((c.Id, p.Ts));
                    // alarm is approximated as first PLC-layer boundary
                    if (c.Layer == ConstraintLayer.Plc)
                        firstAlarm ??= p.Ts;
                }
            }
        }

        var events = new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);
        if (firstAlarm is not null)
        {
            events["alarmRaised"] = firstAlarm.Value;
            events["recoveryStart"] = firstAlarm.Value + TimeSpan.FromSeconds(2);
        }
        events["recoveryDone"] = horizonEnd;

        return Task.FromResult(new ExecutionTrace(
            TraceId: template.TemplateId,
            Points: points,
            Violations: violations,
            Events: events
        ));
    }
}
