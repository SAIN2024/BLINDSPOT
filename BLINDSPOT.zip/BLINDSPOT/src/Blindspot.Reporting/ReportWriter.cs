using Blindspot.Core.Domain;

namespace Blindspot.Reporting;

public sealed class ReportWriter
{
    public void WriteJson(string outDir, object obj, string name)
    {
        Directory.CreateDirectory(outDir);
        var path = Path.Combine(outDir, name);
        File.WriteAllText(path, JsonSerializer.Serialize(obj, new JsonSerializerOptions { WriteIndented = true }));
    }

    public void WriteCsv(string outDir, ExecutionTrace trace, string name)
    {
        Directory.CreateDirectory(outDir);
        var path = Path.Combine(outDir, name);

        var vars = trace.Variables.OrderBy(x => x, StringComparer.OrdinalIgnoreCase).ToList();
        using var sw = new StreamWriter(path, false, Encoding.UTF8);
        sw.Write("timestamp,tsec");
        foreach (var v in vars) sw.Write($",{v}");
        sw.Write(",alarm\n");

        foreach (var p in trace.Points)
        {
            sw.Write($"{p.Timestamp:O},{p.TSec.ToString(CultureInfo.InvariantCulture)}");
            foreach (var v in vars)
            {
                p.Values.TryGetValue(v, out var val);
                sw.Write($",{val.ToString(CultureInfo.InvariantCulture)}");
            }
            var alarm = p.Flags is not null && p.Flags.TryGetValue("alarm", out var a) && a;
            sw.Write($",{(alarm ? 1 : 0)}\n");
        }
    }

    public void WriteGraphviz(string outDir, MultiLayerConstraintModel mcm, string name)
    {
        Directory.CreateDirectory(outDir);
        var path = Path.Combine(outDir, name);

        var sb = new StringBuilder();
        sb.AppendLine("digraph MCM {");
        sb.AppendLine("  rankdir=LR;");
        foreach (var c in mcm.Constraints)
        {
            var label = $"{c.Id}\\n{c.Layer}\\n{c.When}\\n=> {c.Then}";
            sb.AppendLine($"  \"{c.Id}\" [shape=box,label=\"{Escape(label)}\"];");
        }
        foreach (var kv in mcm.EscalationEdges)
        {
            foreach (var to in kv.Value)
                sb.AppendLine($"  \"{kv.Key}\" -> \"{to}\";");
        }
        sb.AppendLine("}");
        File.WriteAllText(path, sb.ToString());
    }

    private static string Escape(string s) => s.Replace("\\", "\\\\").Replace("\"", "\\\"");
}
