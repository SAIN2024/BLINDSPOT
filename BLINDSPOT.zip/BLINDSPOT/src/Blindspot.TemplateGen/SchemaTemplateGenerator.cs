using System.Text.Json;
using Blindspot.Core.Interfaces;
using Blindspot.Core.Models;

namespace Blindspot.TemplateGen;

public sealed class SchemaTemplateGenerator : ITemplateGenerator
{
    private readonly IChatClient _chat;
    public SchemaTemplateGenerator(IChatClient chat) => _chat = chat;

    public async Task<IReadOnlyList<IncidentTemplate>> ProposeTemplatesAsync(
        MultiLayerConstraintModel mcm,
        ConstraintPatterns patterns,
        ManipulableSurface surface,
        CancellationToken ct)
    {
        var promptJson = BuildPrompt(mcm, patterns, surface);
        var raw = await _chat.CompleteJsonAsync(promptJson, ct);

        var dtos = JsonSerializer.Deserialize<List<LlmTemplateDto>>(raw,
            new JsonSerializerOptions { PropertyNameCaseInsensitive = true }) ?? [];

        return dtos.Select(ToTemplate).ToList();
    }

    private static IncidentTemplate ToTemplate(LlmTemplateDto dto) =>
        new(
            TemplateId: dto.TemplateId ?? Guid.NewGuid().ToString("n"),
            TriggerCondition: dto.TriggerCondition ?? "true",
            Variables: dto.Variables ?? [],
            Delta: dto.Delta ?? new Dictionary<string, double>(),
            Timing: new TimeWindow(TimeSpan.FromSeconds(dto.StartOffsetSec), TimeSpan.FromSeconds(dto.EndOffsetSec)),
            ObservationHorizon: TimeSpan.FromSeconds(dto.HorizonSec <= 0 ? 30 : dto.HorizonSec)
        );

    private static string BuildPrompt(MultiLayerConstraintModel mcm, ConstraintPatterns patterns, ManipulableSurface surface)
    {
        var payload = new
        {
            system = "BLINDSPOT template proposer. Output JSON only.",
            task = "Propose incident templates π = <C, v, δ, τ, H> that deplete recovery margins under constraints.",
            schema = new
            {
                type = "array",
                items = new
                {
                    TemplateId = "string",
                    TriggerCondition = "string",
                    Variables = "string[]",
                    Delta = "object<string,double>",
                    StartOffsetSec = "number",
                    EndOffsetSec = "number",
                    HorizonSec = "number"
                }
            },
            constraints = mcm.Constraints.Values.Select(c => new { c.Id, layer = c.Layer.ToString(), when = c.When.Expr, enforce = c.Enforce.Expr, vars = c.RegulatedVars }),
            patterns = patterns.SlackByConstraint,
            coupling = patterns.Coupling,
            manipulable = surface
        };
        return JsonSerializer.Serialize(payload);
    }

    private sealed class LlmTemplateDto
    {
        public string? TemplateId { get; set; }
        public string? TriggerCondition { get; set; }
        public List<string>? Variables { get; set; }
        public Dictionary<string, double>? Delta { get; set; }
        public double StartOffsetSec { get; set; }
        public double EndOffsetSec { get; set; }
        public double HorizonSec { get; set; }
    }
}

public interface IChatClient
{
    Task<string> CompleteJsonAsync(string promptJson, CancellationToken ct);
}
