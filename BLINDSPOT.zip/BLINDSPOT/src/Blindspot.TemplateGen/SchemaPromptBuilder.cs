using Blindspot.Core.Domain;
using Blindspot.TraceAnalysis.Patterns;

namespace Blindspot.TemplateGen;

public sealed class SchemaPromptBuilder
{
    public string Build(MultiLayerConstraintModel mcm, PatternSet patterns, ProposalOptions options)
    {
        var sb = new StringBuilder();
        sb.AppendLine("You are generating BLINDSPOT incident templates under a strict schema.");
        sb.AppendLine("Return ONLY JSON array of templates; no prose.");
        sb.AppendLine("Schema: { id, goal, trigger:{var,op,threshold}, variables:[...], deltaByVar:{var:delta}, duration:{startSec,endSec}, horizonSec }");
        sb.AppendLine($"Goal: {options.Goal}");
        sb.AppendLine("Constraints:");
        foreach (var c in mcm.Constraints)
        {
            sb.AppendLine($"- {c.Id} layer={c.Layer} when=({c.When}) then=({c.Then}) vars=[{string.Join(",", c.RegulatedVariables)}]");
            if (patterns.ByConstraint.TryGetValue(c.Id, out var p))
                sb.AppendLine($"  patterns: D={p.DistanceToConstraint:0.###}, T={p.TimeToConstraint?.ToString("0.###") ?? "NA"} , R={p.RecoveryRate?.ToString("0.###") ?? "NA"}, coupled=[{string.Join(",", p.CoupledConstraints)}]");
        }
        sb.AppendLine("Hard rules:");
        sb.AppendLine("- threshold must be numeric");
        sb.AppendLine("- duration.startSec < duration.endSec and both within [0, 60]");
        sb.AppendLine("- horizonSec within [10, 120]");
        sb.AppendLine("- deltas must be within [-10, 10]");
        return sb.ToString();
    }
}
