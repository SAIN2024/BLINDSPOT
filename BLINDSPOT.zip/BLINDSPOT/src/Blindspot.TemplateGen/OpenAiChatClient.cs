namespace Blindspot.TemplateGen;

/// <summary>
/// Optional adapter for an external chat completion provider. It is not required for compilation.
/// Configure via environment variables:
///   OPENAI_API_KEY
///   OPENAI_MODEL (default: gpt-4o-mini or similar)
///   OPENAI_BASE_URL (default: https://api.openai.com/v1)
/// </summary>
public sealed class OpenAiChatClient : IChatClient
{
    private readonly HttpClient _http;
    private readonly string _apiKey;
    private readonly string _model;
    private readonly Uri _base;

    public OpenAiChatClient(HttpClient http, string apiKey, string? model = null, string? baseUrl = null)
    {
        _http = http;
        _apiKey = apiKey;
        _model = string.IsNullOrWhiteSpace(model) ? "gpt-4o-mini" : model;
        _base = new Uri(string.IsNullOrWhiteSpace(baseUrl) ? "https://api.openai.com/v1" : baseUrl);
    }

    public async Task<string> CompleteAsync(string prompt, CancellationToken ct)
    {
        // Minimal "responses" endpoint-like payload; adjust to your provider.
        var payload = new
        {
            model = _model,
            input = prompt
        };

        using var req = new HttpRequestMessage(HttpMethod.Post, new Uri(_base, "responses"))
        {
            Content = new StringContent(System.Text.Json.JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json")
        };
        req.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", _apiKey);

        using var res = await _http.SendAsync(req, ct);
        var body = await res.Content.ReadAsStringAsync(ct);
        if (!res.IsSuccessStatusCode)
            throw new InvalidOperationException($"Chat provider error {(int)res.StatusCode}: {body}");

        // Parse common fields conservatively.
        using var doc = System.Text.Json.JsonDocument.Parse(body);
        if (doc.RootElement.TryGetProperty("output_text", out var ot) && ot.ValueKind == System.Text.Json.JsonValueKind.String)
            return ot.GetString() ?? "";

        return body;
    }
}
