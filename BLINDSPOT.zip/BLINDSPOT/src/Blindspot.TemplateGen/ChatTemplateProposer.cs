using Blindspot.Core.Domain;
using Blindspot.TraceAnalysis.Patterns;

namespace Blindspot.TemplateGen;

/// <summary>
/// Uses a chat client to propose templates in a constrained JSON schema, then validates and normalizes them.
/// This corresponds to the "template proposal mechanism" described in the paper (Sec 7.3). fileciteturn3file0L1-L6
/// </summary>
public sealed class ChatTemplateProposer : ITemplateProposer
{
    private readonly IChatClient _chat;
    private readonly SchemaPromptBuilder _prompt = new();

    public ChatTemplateProposer(IChatClient chat) => _chat = chat;

    public IReadOnlyList<IncidentTemplate> Propose(MultiLayerConstraintModel mcm, PatternSet patterns, ProposalOptions options)
    {
        // Synchronous wrapper around async completion for CLI usage.
        var prompt = _prompt.Build(mcm, patterns, options);
        var json = _chat.CompleteAsync(prompt, CancellationToken.None).GetAwaiter().GetResult();
        return ValidateAndParse(json, options);
    }

    private static IReadOnlyList<IncidentTemplate> ValidateAndParse(string json, ProposalOptions options)
    {
        var list = new List<IncidentTemplate>();
        using var doc = JsonDocument.Parse(json);

        if (doc.RootElement.ValueKind != JsonValueKind.Array) return list;

        int i = 0;
        foreach (var el in doc.RootElement.EnumerateArray())
        {
            i++;
            if (!el.TryGetProperty("id", out var idEl)) continue;
            var id = idEl.GetString() ?? $"TPL_{i:0000}";
            var goal = el.TryGetProperty("goal", out var gEl) ? gEl.GetString() ?? options.Goal : options.Goal;

            var tr = el.GetProperty("trigger");
            var tv = tr.GetProperty("var").GetString() ?? "Level";
            var op = tr.GetProperty("op").GetString() ?? ">=";
            var thr = tr.GetProperty("threshold").GetDouble();

            var vars = el.GetProperty("variables").EnumerateArray().Select(x => x.GetString() ?? "").Where(x => x.Length > 0).ToList();
            var dbv = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
            foreach (var kv in el.GetProperty("deltaByVar").EnumerateObject())
            {
                var d = kv.Value.GetDouble();
                if (d < -10 || d > 10) continue;
                dbv[kv.Name] = d;
            }

            var dur = el.GetProperty("duration");
            var s = dur.GetProperty("startSec").GetDouble();
            var e = dur.GetProperty("endSec").GetDouble();
            if (s < 0 || e > 60 || s >= e) continue;

            var h = el.TryGetProperty("horizonSec", out var hEl) ? hEl.GetDouble() : options.DefaultHorizonSec;
            h = Math.Clamp(h, 10, 120);

            list.Add(new IncidentTemplate(id, goal, new Condition(tv, ParseOp(op), thr), vars, dbv, new TimeWindow(s, e), h));
        }

        return list;
    }

    private static Blindspot.Core.Domain.ConstraintOp ParseOp(string s) => s switch
    {
        ">" => Blindspot.Core.Domain.ConstraintOp.GreaterThan,
        ">=" => Blindspot.Core.Domain.ConstraintOp.GreaterOrEqual,
        "<" => Blindspot.Core.Domain.ConstraintOp.LessThan,
        "<=" => Blindspot.Core.Domain.ConstraintOp.LessOrEqual,
        "=" => Blindspot.Core.Domain.ConstraintOp.Equal,
        "!=" => Blindspot.Core.Domain.ConstraintOp.NotEqual,
        "<>" => Blindspot.Core.Domain.ConstraintOp.NotEqual,
        _ => Blindspot.Core.Domain.ConstraintOp.GreaterOrEqual
    };
}
