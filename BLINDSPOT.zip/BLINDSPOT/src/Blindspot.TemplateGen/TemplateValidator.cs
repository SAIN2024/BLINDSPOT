using Blindspot.Core.Interfaces;
using Blindspot.Core.Models;

namespace Blindspot.TemplateGen;

public sealed class TemplateValidator : ITemplateValidator
{
    public IReadOnlyList<IncidentTemplate> ValidateAndInstantiate(
        IReadOnlyList<IncidentTemplate> proposed,
        MultiLayerConstraintModel mcm,
        ConstraintPatterns patterns,
        ManipulableSurface surface)
    {
        var ok = new List<IncidentTemplate>();

        foreach (var t in proposed)
        {
            if (t.Variables.Count == 0) continue;
            if (t.Timing.EndOffset <= t.Timing.StartOffset) continue;
            if (t.ObservationHorizon <= TimeSpan.Zero) continue;

            // variables must be writable
            if (t.Variables.Any(v => !surface.WritableVars.Contains(v, StringComparer.OrdinalIgnoreCase)))
                continue;

            // deltas within bounds
            bool boundsOk = true;
            foreach (var v in t.Variables)
            {
                if (!t.Delta.TryGetValue(v, out var d)) { boundsOk = false; break; }
                if (!surface.DeltaBounds.TryGetValue(v, out var b)) { boundsOk = false; break; }
                if (d < b.Min || d > b.Max) { boundsOk = false; break; }
            }
            if (!boundsOk) continue;

            // optional: require at least one constraint relevant to manipulated vars
            var touchesRelevant = mcm.Constraints.Values.Any(c => c.RegulatedVars.Intersect(t.Variables, StringComparer.OrdinalIgnoreCase).Any());
            if (!touchesRelevant) continue;

            ok.Add(t);
        }

        return ok;
    }
}
