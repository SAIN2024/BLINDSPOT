using System.Text.Json;

namespace Blindspot.TemplateGen;

public sealed class MockChatClient : IChatClient
{
    public Task<string> CompleteJsonAsync(string promptJson, CancellationToken ct)
    {
        // Deterministic templates for reproducible runs.
        var templates = new object[]
        {
            new {
                TemplateId = "tpl_level_inflow",
                TriggerCondition = "Level >= 70",
                Variables = new []{ "Inflow" },
                Delta = new Dictionary<string,double>{{"Inflow", +5}},
                StartOffsetSec = 2.0,
                EndOffsetSec = 10.0,
                HorizonSec = 30.0
            },
            new {
                TemplateId = "tpl_pressure_heater",
                TriggerCondition = "Pressure >= 40",
                Variables = new []{ "Heater" },
                Delta = new Dictionary<string,double>{{"Heater", +3}},
                StartOffsetSec = 1.0,
                EndOffsetSec = 8.0,
                HorizonSec = 25.0
            },
            new {
                TemplateId = "tpl_combined",
                TriggerCondition = "Level >= 65",
                Variables = new []{ "Inflow", "Heater" },
                Delta = new Dictionary<string,double>{{"Inflow", +4}, {"Heater", +2}},
                StartOffsetSec = 3.0,
                EndOffsetSec = 12.0,
                HorizonSec = 35.0
            }
        };
        return Task.FromResult(JsonSerializer.Serialize(templates));
    }
}
