using Blindspot.Core.Domain;
using Blindspot.TraceAnalysis.Patterns;

namespace Blindspot.TemplateGen;

/// <summary>
/// Deterministic proposer that enumerates admissible templates from:
///  - constraints (variables, thresholds)
///  - empirically observed patterns (time-to-constraint, recovery rates, coupling)
///
/// It serves as a reproducible baseline and a safe default when no external chat provider is configured.
/// </summary>
public sealed class DeterministicTemplateProposer : ITemplateProposer
{
    public IReadOnlyList<IncidentTemplate> Propose(MultiLayerConstraintModel mcm, PatternSet patterns, ProposalOptions options)
    {
        var rng = new Random(options.Seed);
        var list = new List<IncidentTemplate>();

        foreach (var c in mcm.Constraints)
        {
            if (list.Count >= options.MaxTemplates) break;

            patterns.ByConstraint.TryGetValue(c.Id, out var p);
            var triggerVar = c.When.Variable;
            var trigger = new Condition(triggerVar, c.When.Op, c.When.Threshold * 0.95); // slightly before boundary

            // Choose variables to manipulate: regulated variable plus optionally one coupled constraint variable.
            var vars = new List<string> { c.Then.TargetVariable };

            var coupled = p?.CoupledConstraints ?? Array.Empty<string>();
            if (coupled.Count > 0 && rng.NextDouble() < 0.35)
            {
                var pick = coupled[rng.Next(coupled.Count)];
                var cc = mcm.GetById(pick);
                if (cc is not null) vars.Add(cc.Then.TargetVariable);
            }

            // Magnitudes: small increments bounded using pattern-derived scale.
            var delta = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
            foreach (var v in vars.Distinct(StringComparer.OrdinalIgnoreCase))
            {
                var mag = options.Goal.Equals("Unsafe", StringComparison.OrdinalIgnoreCase) ? 3.0 : 2.0;
                if (p?.RecoveryRate is not null)
                    mag = Math.Clamp(1.0 + 5.0 / (1.0 + p.RecoveryRate.Value), 1.0, 6.0);

                // Random sign depending on condition direction.
                var sign = (c.When.Op == ConstraintOp.GreaterThan || c.When.Op == ConstraintOp.GreaterOrEqual) ? +1 : -1;
                var d = sign * (mag * (0.5 + rng.NextDouble())); // 0.5..1.5 scale
                delta[v] = Math.Round(d, 3);
            }

            // Duration: align with time-to-constraint if available; otherwise 2..10s
            var start = 2.0;
            var end = 10.0;
            if (p?.TimeToConstraint is not null)
            {
                var ttc = Math.Clamp(p.TimeToConstraint.Value, 2, 20);
                start = Math.Max(0.5, ttc * 0.2);
                end = Math.Max(start + 1.0, ttc * 0.8);
            }

            var id = $"TPL_{list.Count + 1:0000}";
            list.Add(new IncidentTemplate(
                Id: id,
                Goal: options.Goal,
                Trigger: trigger,
                Variables: vars.Distinct(StringComparer.OrdinalIgnoreCase).ToList(),
                DeltaByVar: delta,
                Duration: new TimeWindow(Math.Round(start, 3), Math.Round(end, 3)),
                HorizonSec: options.DefaultHorizonSec
            ));
        }

        return list;
    }
}
