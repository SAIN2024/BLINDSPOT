using Blindspot.Core.Domain;
using Blindspot.TraceAnalysis.Patterns;

namespace Blindspot.TemplateGen;

public interface ITemplateProposer
{
    IReadOnlyList<IncidentTemplate> Propose(MultiLayerConstraintModel mcm, PatternSet patterns, ProposalOptions options);
}

public sealed record ProposalOptions(
    int MaxTemplates = 30,
    string Goal = "Infeasible", // Infeasible | Unsafe | Escalation
    int Seed = 7,
    double DefaultHorizonSec = 30
);

public interface IChatClient
{
    Task<string> CompleteAsync(string prompt, CancellationToken ct);
}
