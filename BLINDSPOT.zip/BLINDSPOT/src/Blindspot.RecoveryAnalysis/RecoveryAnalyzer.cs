using Blindspot.Core.Domain;

namespace Blindspot.RecoveryAnalysis;

public sealed class RecoveryAnalyzer
{
    /// <summary>
    /// Implements Algorithm 1 (Recovery feasibility and safety analysis) from the paper. fileciteturn3file4L3-L27
    /// </summary>
    public RecoveryClassification Classify(ExecutionTrace trace, MultiLayerConstraintModel mcm)
    {
        var vr = GetRecoveryVariables(mcm);
        var td = GetRecoveryInitiationTime(trace, vr);
        var tc = GetRecoveryCompletionTime(trace, vr);
        if (tc is null) tc = DateTimeOffset.MaxValue;

        var violations = GetConstraintViolations(trace, mcm).OrderBy(v => v.time).ToList();

        foreach (var (constraintId, time, regulated) in violations)
        {
            if (!regulated.Any(v => vr.Contains(v)))
                continue;

            if (td is not null && time >= td.Value && time < tc.Value)
            {
                return new RecoveryClassification(
                    TraceId: trace.TraceId,
                    Outcome: RecoveryOutcome.Infeasible,
                    DetectionTime: GetDetectionTime(trace),
                    RecoveryStartTime: td,
                    RecoveryCompleteTime: tc == DateTimeOffset.MaxValue ? null : tc,
                    SupportingViolationConstraintId: constraintId,
                    Notes: "Constraint violation occurred during recovery window."
                );
            }

            if (tc != DateTimeOffset.MaxValue && time >= tc.Value)
            {
                return new RecoveryClassification(
                    TraceId: trace.TraceId,
                    Outcome: RecoveryOutcome.Unsafe,
                    DetectionTime: GetDetectionTime(trace),
                    RecoveryStartTime: td,
                    RecoveryCompleteTime: tc,
                    SupportingViolationConstraintId: constraintId,
                    Notes: "Constraint violation occurred after recovery completion, indicating secondary hazard."
                );
            }
        }

        return new RecoveryClassification(
            TraceId: trace.TraceId,
            Outcome: RecoveryOutcome.Recoverable,
            DetectionTime: GetDetectionTime(trace),
            RecoveryStartTime: td,
            RecoveryCompleteTime: tc == DateTimeOffset.MaxValue ? null : tc,
            SupportingViolationConstraintId: null,
            Notes: "No causally related constraint violations observed."
        );
    }

    private static HashSet<string> GetRecoveryVariables(MultiLayerConstraintModel mcm)
    {
        // Conservative: anything controlled by Operator constraints is treated as recovery variable set.
        var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var c in mcm.Constraints.Where(c => c.Layer == ConstraintLayer.Operator))
            foreach (var v in c.RegulatedVariables)
                set.Add(v);
        return set;
    }

    private static DateTimeOffset? GetDetectionTime(ExecutionTrace trace)
    {
        var p = trace.Points.FirstOrDefault(x => x.Flags is not null && x.Flags.TryGetValue("alarm", out var a) && a);
        return p?.Timestamp;
    }

    private static DateTimeOffset? GetRecoveryInitiationTime(ExecutionTrace trace, HashSet<string> vr)
    {
        // Proxy: first time any recovery variable changes materially after detection.
        var det = GetDetectionTime(trace);
        if (det is null) return null;

        foreach (var v in vr)
        {
            double? prev = null;
            foreach (var p in trace.Points.Where(p => p.Timestamp >= det.Value))
            {
                if (!p.Values.TryGetValue(v, out var cur)) continue;
                prev ??= cur;
                if (Math.Abs(cur - prev.Value) > 1e-3)
                    return p.Timestamp;
            }
        }

        return det;
    }

    private static DateTimeOffset? GetRecoveryCompletionTime(ExecutionTrace trace, HashSet<string> vr)
    {
        // Proxy: last time recovery variables change, then remain stable for a grace period.
        var det = GetDetectionTime(trace);
        if (det is null) return null;

        var after = trace.Points.Where(p => p.Timestamp >= det.Value).ToList();
        if (after.Count < 10) return null;

        DateTimeOffset? lastChange = null;
        foreach (var v in vr)
        {
            double? prev = null;
            foreach (var p in after)
            {
                if (!p.Values.TryGetValue(v, out var cur)) continue;
                prev ??= cur;
                if (Math.Abs(cur - prev.Value) > 1e-3)
                {
                    lastChange = p.Timestamp;
                    prev = cur;
                }
            }
        }

        return lastChange;
    }

    private static IEnumerable<(string id, DateTimeOffset time, IReadOnlyList<string> regulated)> GetConstraintViolations(ExecutionTrace trace, MultiLayerConstraintModel mcm)
    {
        foreach (var c in mcm.Constraints)
        {
            // "Violation" occurs when condition is met (boundary reached) and slack <= 0 (proxy).
            foreach (var p in trace.Points)
            {
                if (c.When.Variable == "TRUE") continue;
                if (!p.Values.ContainsKey(c.When.Variable)) continue;
                if (c.When.Evaluate(p.Values))
                    yield return (c.Id, p.Timestamp, c.RegulatedVariables);
            }
        }
    }
}
