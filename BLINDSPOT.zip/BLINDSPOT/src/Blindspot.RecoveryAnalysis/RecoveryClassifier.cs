using Blindspot.Core.Models;

namespace Blindspot.RecoveryAnalysis;

public enum RecoveryOutcome
{
    NoAlarm,
    Recoverable,
    InfeasibleRecovery,
    UnsafeRecovery
}

public sealed record RecoveryResult(
    string TemplateId,
    RecoveryOutcome Outcome,
    string Rationale,
    IReadOnlyList<(string ConstraintId, DateTime Ts)> Violations,
    IReadOnlyDictionary<string, DateTime> Events
);

/// <summary>
/// Deterministic classification:
/// - Infeasible: ESD boundary reached before recoveryStart
/// - Unsafe: operator boundary reached after recoveryStart (during recovery)
/// - Else recoverable
/// </summary>
public sealed class RecoveryClassifier
{
    public RecoveryResult Classify(MultiLayerConstraintModel mcm, ExecutionTrace trace)
    {
        if (!trace.Events.TryGetValue("alarmRaised", out var alarmTs))
            return new(trace.TraceId, RecoveryOutcome.NoAlarm, "No alarm raised within horizon.", trace.Violations, trace.Events);

        var recoveryStart = trace.Events.TryGetValue("recoveryStart", out var rs) ? rs : alarmTs;

        var esdIds = mcm.Constraints.Values.Where(c => c.Layer == ConstraintLayer.Esd)
            .Select(c => c.Id).ToHashSet(StringComparer.OrdinalIgnoreCase);

        if (trace.Violations.Any(v => esdIds.Contains(v.ConstraintId) && v.Ts <= recoveryStart))
        {
            return new(trace.TraceId, RecoveryOutcome.InfeasibleRecovery,
                "Alarm raised, but ESD boundary reached before recovery could begin.",
                trace.Violations, trace.Events);
        }

        var opIds = mcm.Constraints.Values.Where(c => c.Layer == ConstraintLayer.Operator)
            .Select(c => c.Id).ToHashSet(StringComparer.OrdinalIgnoreCase);

        if (trace.Violations.Any(v => opIds.Contains(v.ConstraintId) && v.Ts >= recoveryStart))
        {
            return new(trace.TraceId, RecoveryOutcome.UnsafeRecovery,
                "Recovery initiated, but operator-layer constraints became violated (unsafe recovery).",
                trace.Violations, trace.Events);
        }

        return new(trace.TraceId, RecoveryOutcome.Recoverable,
            "Alarm raised; recovery started before ESD boundary; no operator-layer violations during recovery.",
            trace.Violations, trace.Events);
    }
}
