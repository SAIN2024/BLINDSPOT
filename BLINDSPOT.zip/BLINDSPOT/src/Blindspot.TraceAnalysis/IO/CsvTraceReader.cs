using Blindspot.Core.Domain;

namespace Blindspot.TraceAnalysis.IO;

/// <summary>
/// Reads CSV traces:
/// timestamp, tsec, var1, var2, ..., alarm(optional), mode(optional)
/// timestamp is ISO-8601; tsec is seconds since start.
/// </summary>
public sealed class CsvTraceReader
{
    public ExecutionTrace Read(string traceId, string path)
    {
        var lines = File.ReadAllLines(path);
        if (lines.Length < 2) throw new InvalidDataException("Trace CSV needs header + data.");

        var header = lines[0].Split(',').Select(h => h.Trim()).ToArray();
        int tsIdx = Array.FindIndex(header, h => h.Equals("timestamp", StringComparison.OrdinalIgnoreCase));
        int tIdx = Array.FindIndex(header, h => h.Equals("tsec", StringComparison.OrdinalIgnoreCase));
        if (tsIdx < 0 || tIdx < 0) throw new InvalidDataException("CSV must contain timestamp,tsec columns.");

        var points = new List<TracePoint>();
        for (int i = 1; i < lines.Length; i++)
        {
            var row = lines[i].Split(',');
            if (row.Length != header.Length) continue;

            var ts = DateTimeOffset.Parse(row[tsIdx].Trim(), CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal);
            var t = double.Parse(row[tIdx].Trim(), CultureInfo.InvariantCulture);

            var values = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
            var flags = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);

            for (int c = 0; c < header.Length; c++)
            {
                if (c == tsIdx || c == tIdx) continue;

                var key = header[c];
                var s = row[c].Trim();

                if (bool.TryParse(s, out var b)) flags[key] = b;
                else if (double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out var d)) values[key] = d;
                else if (string.Equals(s, "1", StringComparison.OrdinalIgnoreCase)) flags[key] = true;
                else if (string.Equals(s, "0", StringComparison.OrdinalIgnoreCase)) flags[key] = false;
            }

            points.Add(new TracePoint(ts, t, values, flags.Count == 0 ? null : flags));
        }

        return new ExecutionTrace(traceId, points);
    }
}
