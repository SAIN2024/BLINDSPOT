using Blindspot.Core.Interfaces;
using Blindspot.Core.Models;

namespace Blindspot.TraceAnalysis;

/// <summary>
/// Adds deterministic ranking of constraints/templates based on slack stats.
/// </summary>
public static class PatternRanking
{
    public static IReadOnlyList<string> RankConstraintsByRisk(MultiLayerConstraintModel mcm, ConstraintPatterns patterns)
    {
        // Risk proxy: lower min slack and shorter TTC => higher risk
        return mcm.Constraints.Keys
            .OrderBy(id =>
            {
                if (!patterns.SlackByConstraint.TryGetValue(id, out var s)) return double.PositiveInfinity;
                var ttc = double.IsFinite(s.TypicalTimeToConstraintSec) ? s.TypicalTimeToConstraintSec : 1e9;
                return (s.TypicalMinSlack + 1.0) * ttc;
            })
            .ToList();
    }
}
