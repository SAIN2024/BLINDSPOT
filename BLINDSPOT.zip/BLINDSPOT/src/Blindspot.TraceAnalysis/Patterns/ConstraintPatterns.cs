namespace Blindspot.TraceAnalysis.Patterns;

public sealed record ConstraintPattern(
    string ConstraintId,
    double DistanceToConstraint, // min slack
    double? TimeToConstraint,    // extrapolated time based on avg decay
    double? RecoveryRate,        // max sustained positive slope after intervention
    IReadOnlyList<string> CoupledConstraints // co-activated in segment
);

public sealed class PatternSet
{
    public IReadOnlyDictionary<string, ConstraintPattern> ByConstraint { get; }
    public PatternSet(IReadOnlyDictionary<string, ConstraintPattern> byConstraint) => ByConstraint = byConstraint;
}
