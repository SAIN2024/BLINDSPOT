using Blindspot.Core.Domain;
using Blindspot.TraceAnalysis.Slack;

namespace Blindspot.TraceAnalysis.Patterns;

public sealed class PatternExtractor
{
    private readonly SlackComputer _slack = new();

    /// <summary>
    /// Extracts patterns described in Sec 7.2: distance-to-constraint, time-to-constraint, recovery effectiveness,
    /// and coupling (co-activation ordering) using trace segments centered around activation (or minimum slack proxy).
    /// </summary>
    public PatternSet Extract(MultiLayerConstraintModel mcm, IReadOnlyList<ExecutionTrace> traces)
    {
        var patterns = new Dictionary<string, ConstraintPattern>(StringComparer.OrdinalIgnoreCase);

        foreach (var c in mcm.Constraints)
        {
            var allMin = new List<double>();
            var allTimes = new List<double>();
            var allRec = new List<double>();
            var coupled = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            foreach (var tr in traces)
            {
                var series = _slack.Compute(c, tr);
                if (series.Samples.Count < 5) continue;

                // Identify proxy activation point: t* where slack is minimized.
                var (tStar, minSlack) = series.Samples.Aggregate((tSec: 0.0, slack: double.MaxValue),
                    (best, s) => s.slack < best.slack ? s : best);

                allMin.Add(minSlack);

                // Estimate average decay rate in a window before t*
                var pre = series.Samples.Where(s => s.tSec <= tStar).ToList();
                if (pre.Count >= 5)
                {
                    var dt = pre[^1].tSec - pre[0].tSec;
                    if (dt > 1e-6)
                    {
                        var ds = pre[^1].slack - pre[0].slack;
                        var avgSlope = ds / dt; // negative when approaching boundary
                        if (avgSlope < -1e-9)
                        {
                            var tTo = pre[^1].slack / Math.Abs(avgSlope);
                            allTimes.Add(tTo);
                        }
                    }
                }

                // Recovery effectiveness proxy: max positive slope after t*
                var post = series.Samples.Where(s => s.tSec >= tStar).ToList();
                if (post.Count >= 5)
                {
                    double maxSlope = 0;
                    for (int i = 1; i < post.Count; i++)
                    {
                        var dt = post[i].tSec - post[i - 1].tSec;
                        if (dt <= 1e-9) continue;
                        var slope = (post[i].slack - post[i - 1].slack) / dt;
                        if (slope > maxSlope) maxSlope = slope;
                    }
                    if (maxSlope > 1e-9) allRec.Add(maxSlope);
                }

                // Coupling proxy: which other constraints are activated near t*
                foreach (var other in mcm.Constraints)
                {
                    if (other.Id.Equals(c.Id, StringComparison.OrdinalIgnoreCase)) continue;
                    var os = _slack.Compute(other, tr);
                    if (os.Samples.Count == 0) continue;
                    // consider "activated" if slack hits ~0 within +/- window
                    var win = os.Samples.Where(s => Math.Abs(s.tSec - tStar) <= 5).ToList();
                    if (win.Any(s => s.slack <= 1e-6)) coupled.Add(other.Id);
                }
            }

            if (allMin.Count == 0) continue;

            patterns[c.Id] = new ConstraintPattern(
                ConstraintId: c.Id,
                DistanceToConstraint: allMin.Min(),
                TimeToConstraint: allTimes.Count == 0 ? null : allTimes.Average(),
                RecoveryRate: allRec.Count == 0 ? null : allRec.Max(),
                CoupledConstraints: coupled.ToList()
            );
        }

        return new PatternSet(patterns);
    }
}
