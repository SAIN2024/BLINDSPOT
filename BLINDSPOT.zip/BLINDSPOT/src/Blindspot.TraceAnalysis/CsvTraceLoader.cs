using System.Globalization;
using Blindspot.Core.Models;

namespace Blindspot.TraceAnalysis;

/// <summary>
/// Loads a trace CSV:
///   ts,Var1,Var2,...
///   2026-01-01T00:00:00Z,10,20,...
/// </summary>
public static class CsvTraceLoader
{
    public static IReadOnlyList<TracePoint> Load(string path)
    {
        var lines = File.ReadAllLines(path);
        if (lines.Length < 2) return [];

        var header = lines[0].Split(',').Select(s => s.Trim()).ToArray();
        if (header.Length < 2 || !header[0].Equals("ts", StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("First column must be 'ts'.");

        var vars = header.Skip(1).ToArray();
        var points = new List<TracePoint>();

        for (int i = 1; i < lines.Length; i++)
        {
            var cols = lines[i].Split(',');
            if (cols.Length != header.Length) continue;

            var ts = DateTime.Parse(cols[0], null, DateTimeStyles.AdjustToUniversal | DateTimeStyles.AssumeUniversal);
            var dict = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);

            for (int j = 0; j < vars.Length; j++)
            {
                if (double.TryParse(cols[j + 1], NumberStyles.Float, CultureInfo.InvariantCulture, out var v))
                    dict[vars[j]] = v;
            }

            points.Add(new TracePoint(ts, dict));
        }

        return points;
    }
}
