using Blindspot.Core.Domain;

namespace Blindspot.TraceAnalysis.Slack;

public sealed record SlackSeries(string ConstraintId, IReadOnlyList<(double tSec, double slack)> Samples);

public sealed class SlackComputer
{
    /// <summary>
    /// Slack is defined as signed distance to constraint boundary. For common monotonic conditions:
    ///  - var <= thr  => slack = thr - var
    ///  - var >= thr  => slack = var - thr
    /// For other cases we compute an absolute distance with sign chosen so that slack>0 indicates "safe margin remaining".
    /// </summary>
    public SlackSeries Compute(Constraint c, ExecutionTrace trace)
    {
        var list = new List<(double tSec, double slack)>(trace.Points.Count);
        foreach (var p in trace.Points)
        {
            if (!p.Values.TryGetValue(c.When.Variable, out var v))
                continue;

            var slack = c.When.Op switch
            {
                ConstraintOp.LessThan or ConstraintOp.LessOrEqual => c.When.Threshold - v,
                ConstraintOp.GreaterThan or ConstraintOp.GreaterOrEqual => v - c.When.Threshold,
                _ => Math.Abs(c.When.Threshold - v)
            };
            list.Add((p.TSec, slack));
        }
        return new SlackSeries(c.Id, list);
    }
}
