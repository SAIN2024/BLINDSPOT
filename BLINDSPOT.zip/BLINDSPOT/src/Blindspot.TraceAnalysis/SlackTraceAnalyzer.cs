using Blindspot.Core.Interfaces;
using Blindspot.Core.Models;
using Blindspot.Core.Utils;

namespace Blindspot.TraceAnalysis;

/// <summary>
/// Computes per-constraint slack stats + a lightweight coupling map.
/// Slack definition supports simple comparisons only.
/// </summary>
public sealed class SlackTraceAnalyzer : ITraceAnalyzer
{
    public Task<ConstraintPatterns> AnalyzeAsync(MultiLayerConstraintModel mcm, IReadOnlyList<TracePoint> trace, CancellationToken ct)
    {
        var slackBy = new Dictionary<string, SlackStats>(StringComparer.OrdinalIgnoreCase);

        foreach (var c in mcm.Constraints.Values)
        {
            var parsed = Expr.TryParseSimpleComparison(c.When.Expr);
            if (parsed is null) continue;

            var (varName, op, boundary) = parsed.Value;
            var slacks = new List<(DateTime t, double slack)>();

            foreach (var p in trace)
            {
                if (!p.Vars.TryGetValue(varName, out var val)) continue;
                var slack = op switch
                {
                    ">" or ">=" => boundary - val,
                    "<" or "<=" => val - boundary,
                    _ => double.NaN
                };
                if (double.IsNaN(slack)) continue;
                slacks.Add((p.Ts, slack));
            }

            if (slacks.Count < 3) continue;

            var slopes = new List<double>();
            for (int i = 1; i < slacks.Count; i++)
            {
                var dt = (slacks[i].t - slacks[i - 1].t).TotalSeconds;
                if (dt <= 0) continue;
                slopes.Add((slacks[i].slack - slacks[i - 1].slack) / dt);
            }

            var esc = slopes.Where(s => s < 0).Select(Math.Abs).DefaultIfEmpty(0).Average();
            var rec = slopes.Where(s => s > 0).DefaultIfEmpty(0).Average();
            var minSlack = slacks.Min(x => x.slack);

            var current = slacks[^1].slack;
            var ttc = esc > 1e-9 ? Math.Max(0, current / esc) : double.PositiveInfinity;

            slackBy[c.Id] = new SlackStats(esc, rec, minSlack, ttc);
        }

        var coupling = new Dictionary<string, CouplingStats>(StringComparer.OrdinalIgnoreCase);
        var all = mcm.Constraints.Values.ToList();

        foreach (var c in all)
        {
            var coupled = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            foreach (var o in all)
            {
                if (o.Id == c.Id) continue;
                if (o.RegulatedVars.Intersect(c.RegulatedVars, StringComparer.OrdinalIgnoreCase).Any())
                    coupled.Add(o.Id);
            }

            foreach (var e in mcm.Edges)
            {
                if (e.FromId.Equals(c.Id, StringComparison.OrdinalIgnoreCase)) coupled.Add(e.ToId);
                if (e.ToId.Equals(c.Id, StringComparison.OrdinalIgnoreCase)) coupled.Add(e.FromId);
            }

            coupling[c.Id] = new CouplingStats(coupled.ToList());
        }

        return Task.FromResult(new ConstraintPatterns(slackBy, coupling));
    }
}
