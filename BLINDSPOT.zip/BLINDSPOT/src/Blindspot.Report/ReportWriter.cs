using System.Text.Json;
using Blindspot.Core.Models;
using Blindspot.RecoveryAnalysis;

namespace Blindspot.Report;

public static class ReportWriter
{
    public static void WriteJson(string path, IReadOnlyList<RecoveryResult> results, object meta, MetricSink? metrics = null)
    {
        var payload = new
        {
            meta,
            metrics = metrics?.Metrics,
            results
        };

        File.WriteAllText(path, JsonSerializer.Serialize(payload, new JsonSerializerOptions { WriteIndented = true }));
    }

    public static void WriteCsv(string path, IReadOnlyList<RecoveryResult> results)
    {
        using var sw = new StreamWriter(path);
        sw.WriteLine("template_id,outcome,rationale,alarm_ts,recovery_start,recovery_done,violations");
        foreach (var r in results)
        {
            r.Events.TryGetValue("alarmRaised", out var a);
            r.Events.TryGetValue("recoveryStart", out var s);
            r.Events.TryGetValue("recoveryDone", out var d);

            var vio = string.Join('|', r.Violations.Select(v => $"{v.ConstraintId}@{v.Ts:o}"));
            sw.WriteLine($"{Esc(r.TemplateId)},{r.Outcome},{Esc(r.Rationale)},{a:o},{s:o},{d:o},{Esc(vio)}");
        }

        static string Esc(string? x) => "\"" + (x ?? "").Replace("\"", "\"\"") + "\"";
    }
}
