using System.Text;
using Blindspot.Core.Models;

namespace Blindspot.Report;

/// <summary>
/// Writes the MCM graph to Graphviz DOT for visualization.
/// </summary>
public static class GraphvizExporter
{
    public static void WriteDot(string path, MultiLayerConstraintModel mcm)
    {
        var sb = new StringBuilder();
        sb.AppendLine("digraph MCM {");
        sb.AppendLine("  rankdir=LR;");
        foreach (var c in mcm.Constraints.Values)
        {
            var shape = c.Layer switch
            {
                ConstraintLayer.Plc => "box",
                ConstraintLayer.Operator => "ellipse",
                ConstraintLayer.Esd => "octagon",
                _ => "box"
            };
            sb.AppendLine($"  \"{c.Id}\" [shape={shape}];");
        }

        foreach (var e in mcm.Edges)
            sb.AppendLine($"  \"{e.FromId}\" -> \"{e.ToId}\" [label=\"{e.Type}\"];");

        sb.AppendLine("}");
        File.WriteAllText(path, sb.ToString());
    }
}
