using System.Text.Json;
using Blindspot.ConstraintExtraction;
using Blindspot.Core.Interfaces;
using Blindspot.Execution;
using Blindspot.RecoveryAnalysis;
using Blindspot.TemplateGen;
using Blindspot.TraceAnalysis;

static void Assert(bool cond, string msg)
{
    if (!cond) throw new Exception("SELFTEST FAILED: " + msg);
}

var root = "samples/water";

var plc = File.ReadAllText(Path.Combine(root, "plc.st"));
var esd = File.ReadAllText(Path.Combine(root, "esd.st"));
var op  = File.ReadAllText(Path.Combine(root, "operator_rules.json"));
var trace = CsvTraceLoader.Load(Path.Combine(root, "trace.csv"));
var surface = JsonSerializer.Deserialize<ManipulableSurface>(
    File.ReadAllText(Path.Combine(root, "manipulable.json")),
    new JsonSerializerOptions { PropertyNameCaseInsensitive = true })!;

IConstraintExtractor extractor = new SimpleConstraintExtractor();
var mcm = await extractor.ExtractAsync(new(plc, esd, op), CancellationToken.None);
Assert(mcm.Constraints.Count >= 3, "expected >=3 constraints");
Assert(mcm.Edges.Count >= 1, "expected >=1 edges");

var analyzer = new SlackTraceAnalyzer();
var patterns = await analyzer.AnalyzeAsync(mcm, trace, CancellationToken.None);

var tgen = new SchemaTemplateGenerator(new MockChatClient());
var proposed = await tgen.ProposeTemplatesAsync(mcm, patterns, surface, CancellationToken.None);

var validator = new TemplateValidator();
var templates = validator.ValidateAndInstantiate(proposed, mcm, patterns, surface);
Assert(templates.Count >= 1, "expected >=1 valid template");

var exec = new MockPlcExecutor();
var classifier = new RecoveryClassifier();

foreach (var t in templates)
{
    var tr = await exec.ExecuteAsync(mcm, t, trace, CancellationToken.None);
    var res = classifier.Classify(mcm, tr);
    Assert(res.TemplateId == t.TemplateId, "template id mismatch");
}

Console.WriteLine("SELFTEST OK");
