using Blindspot.ConstraintExtraction;
using Blindspot.TraceAnalysis.Patterns;
using Blindspot.TemplateGen;
using Blindspot.Execution;
using Blindspot.RecoveryAnalysis;
using Blindspot.Reporting;

static class Program
{
    static int Main()
    {
        try
        {
            Console.WriteLine("SelfTest: running built-in sample end-to-end...");

            var sampleRoot = Path.Combine("samples", "water");
            var plcText = File.ReadAllText(Path.Combine(sampleRoot, "plc.st"));
            var esdText = File.ReadAllText(Path.Combine(sampleRoot, "esd.st"));
            var opJson = File.ReadAllText(Path.Combine(sampleRoot, "operator.json"));

            var extractor = new ConstraintExtractionPipeline();
            var (mcm, _) = extractor.Run(plcText, esdText, opJson);

            var traces = new List<Blindspot.Core.Domain.ExecutionTrace>(); // patterns can run without traces as well

            var patternExtractor = new PatternExtractor();
            var patterns = patternExtractor.Extract(mcm, traces);

            var proposer = new DeterministicTemplateProposer();
            var templates = proposer.Propose(mcm, patterns, new ProposalOptions(10, "Infeasible", 7, 30));

            var exec = new VirtualPlcBackend();
            var screen = new PreScreening();
            var analyzer = new RecoveryAnalyzer();

            int ok = 0;
            int n = 0;
            foreach (var tpl in templates)
            {
                n++;
                var res = exec.Execute(new ExecutionRequest($"self_{n:000}", tpl, mcm, "water", 0.2));
                if (!screen.Accept(res.Trace, mcm, out _)) continue;
                var cls = analyzer.Classify(res.Trace, mcm);
                Console.WriteLine($"{res.Trace.TraceId} => {cls.Outcome}");
                ok++;
            }

            Console.WriteLine($"SelfTest: completed {ok} accepted runs.");
            return ok > 0 ? 0 : 1;
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            return 2;
        }
    }
}
