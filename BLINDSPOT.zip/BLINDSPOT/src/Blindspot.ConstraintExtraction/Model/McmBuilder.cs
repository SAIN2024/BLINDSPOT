using Blindspot.Core.Domain;

namespace Blindspot.ConstraintExtraction.Model;

public sealed class McmBuilder
{
    /// <summary>
    /// Builds a directed escalation graph by:
    ///  - grouping constraints by regulated variables
    ///  - ordering them by layer (Control -> Operator -> Safety) and threshold direction
    ///  - linking neighbors as escalation/handoff edges
    /// </summary>
    public MultiLayerConstraintModel Build(IReadOnlyList<Constraint> constraints)
    {
        var edges = new Dictionary<string, IReadOnlyList<string>>(StringComparer.OrdinalIgnoreCase);

        foreach (var group in constraints
                     .SelectMany(c => c.RegulatedVariables.Select(v => (v, c)))
                     .GroupBy(x => x.v, StringComparer.OrdinalIgnoreCase))
        {
            var ordered = group.Select(x => x.c)
                .Distinct()
                .OrderBy(c => c.Layer)
                .ThenBy(c => c.When.Threshold)
                .ToList();

            for (int i = 0; i + 1 < ordered.Count; i++)
            {
                var a = ordered[i].Id;
                var b = ordered[i + 1].Id;
                edges[a] = edges.TryGetValue(a, out var next) ? next.Concat(new[] { b }).Distinct().ToList() : new List<string> { b };
            }
        }

        return new MultiLayerConstraintModel(constraints, edges);
    }
}
