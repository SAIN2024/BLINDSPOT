using Blindspot.Core.Domain;

namespace Blindspot.ConstraintExtraction.Parsers;

/// <summary>
/// Parses machine-readable operator procedure rules in JSON or CSV.
/// JSON schema:
/// {
///   "rules":[{"id":"OP1","when":{"var":"Level","op":">","threshold":80},"then":{"kind":"RateLimit","target":"Valve","maxRatePerSec":5,"units":"%/s"}}]
/// }
/// </summary>
public sealed class GuidelineRuleParser
{
    public IReadOnlyList<Constraint> ExtractFromJson(string json, string idPrefix)
    {
        using var doc = JsonDocument.Parse(json);
        var root = doc.RootElement;
        if (!root.TryGetProperty("rules", out var rules) || rules.ValueKind != JsonValueKind.Array)
            return Array.Empty<Constraint>();

        var list = new List<Constraint>();
        foreach (var r in rules.EnumerateArray())
        {
            var id = r.TryGetProperty("id", out var idEl) ? idEl.GetString() ?? $"{idPrefix}_{list.Count + 1}" : $"{idPrefix}_{list.Count + 1}";
            var when = ParseCond(r.GetProperty("when"));
            var then = ParseAction(r.GetProperty("then"));
            var vars = new[] { then.TargetVariable };
            list.Add(new Constraint(id, ConstraintLayer.Operator, when, then, vars));
        }
        return list;
    }

    private static Condition ParseCond(JsonElement el)
    {
        var v = el.GetProperty("var").GetString() ?? throw new InvalidDataException("when.var missing");
        var op = el.GetProperty("op").GetString() ?? ">";
        var thr = el.GetProperty("threshold").GetDouble();
        return new Condition(v, ParseOp(op), thr, el.TryGetProperty("units", out var u) ? u.GetString() : null);
    }

    private static EnforcementAction ParseAction(JsonElement el)
    {
        var kind = el.GetProperty("kind").GetString() ?? "Clamp";
        var target = el.GetProperty("target").GetString() ?? throw new InvalidDataException("then.target missing");
        var units = el.TryGetProperty("units", out var u) ? u.GetString() : null;

        return kind switch
        {
            "RateLimit" => new EnforcementAction(ActionKind.RateLimit, target, 0, MaxRatePerSec: el.GetProperty("maxRatePerSec").GetDouble(), Units: units),
            "Clamp" => new EnforcementAction(ActionKind.Clamp, target, el.GetProperty("value").GetDouble(), null, units),
            "SetDiscrete" => new EnforcementAction(ActionKind.SetDiscrete, target, el.GetProperty("value").GetDouble(), null, units),
            _ => new EnforcementAction(ActionKind.Clamp, target, el.TryGetProperty("value", out var v) ? v.GetDouble() : 0, null, units)
        };
    }

    private static ConstraintOp ParseOp(string s) => s switch
    {
        ">" => ConstraintOp.GreaterThan,
        ">=" => ConstraintOp.GreaterOrEqual,
        "<" => ConstraintOp.LessThan,
        "<=" => ConstraintOp.LessOrEqual,
        "=" => ConstraintOp.Equal,
        "!=" => ConstraintOp.NotEqual,
        "<>" => ConstraintOp.NotEqual,
        _ => ConstraintOp.GreaterThan
    };
}
