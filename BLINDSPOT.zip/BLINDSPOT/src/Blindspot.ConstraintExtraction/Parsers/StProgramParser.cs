using Blindspot.Core.Domain;

namespace Blindspot.ConstraintExtraction.Parsers;

/// <summary>
/// Minimal IEC 61131-3 ST/SCL conditional extraction for research workflows.
/// It extracts condition-action patterns of the form:
///   IF <var> <op> <number> THEN
///       <target> := <value>;
///   END_IF;
/// and rate limits expressed as comments:
///   (* RATE_LIMIT target=Valve max_rate=2 units=%/s *)
///
/// This parser is intentionally conservative: it only extracts constraints it can parse unambiguously.
/// </summary>
public sealed class StProgramParser
{
    private static readonly Regex IfRegex = new(@"^\s*IF\s+(?<var>[A-Za-z_][A-Za-z0-9_]*)\s*(?<op>>=|<=|>|<|=|<>)\s*(?<num>-?\d+(\.\d+)?)\s*THEN\s*$", RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Regex AssignRegex = new(@"^\s*(?<target>[A-Za-z_][A-Za-z0-9_]*)\s*:=\s*(?<num>-?\d+(\.\d+)?)\s*;\s*$", RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Regex RateRegex = new(@"\(\*\s*RATE_LIMIT\s+target=(?<target>[A-Za-z_][A-Za-z0-9_]*)\s+max_rate=(?<rate>-?\d+(\.\d+)?)\s*(units=(?<units>[^\s\*]+))?\s*\*\)", RegexOptions.IgnoreCase | RegexOptions.Compiled);

    public IReadOnlyList<Constraint> Extract(string text, ConstraintLayer layer, string idPrefix)
    {
        var constraints = new List<Constraint>();
        var lines = text.Split('\n');
        Condition? pending = null;
        int idx = 0;

        foreach (var raw in lines)
        {
            var line = raw.TrimEnd('\r');
            idx++;

            var rm = RateRegex.Match(line);
            if (rm.Success)
            {
                var target = rm.Groups["target"].Value;
                var rate = double.Parse(rm.Groups["rate"].Value, CultureInfo.InvariantCulture);
                var units = rm.Groups["units"].Success ? rm.Groups["units"].Value : null;

                // Rate limits often depend on some upstream state; if none is present we treat it as always-on.
                var when = pending ?? new Condition("TRUE", ConstraintOp.Equal, 1, null);

                var c = new Constraint(
                    Id: $"{idPrefix}_RL_{constraints.Count + 1}",
                    Layer: layer,
                    When: when,
                    Then: new EnforcementAction(ActionKind.RateLimit, target, 0, MaxRatePerSec: rate, Units: units),
                    RegulatedVariables: new[] { target }
                );
                constraints.Add(c);
                continue;
            }

            var mIf = IfRegex.Match(line);
            if (mIf.Success)
            {
                pending = new Condition(
                    Variable: mIf.Groups["var"].Value,
                    Op: ParseOp(mIf.Groups["op"].Value),
                    Threshold: double.Parse(mIf.Groups["num"].Value, CultureInfo.InvariantCulture)
                );
                continue;
            }

            var mAsn = AssignRegex.Match(line);
            if (mAsn.Success && pending is not null)
            {
                var target = mAsn.Groups["target"].Value;
                var value = double.Parse(mAsn.Groups["num"].Value, CultureInfo.InvariantCulture);
                var c = new Constraint(
                    Id: $"{idPrefix}_ASG_{constraints.Count + 1}",
                    Layer: layer,
                    When: pending,
                    Then: new EnforcementAction(ActionKind.Clamp, target, value),
                    RegulatedVariables: new[] { target }
                );
                constraints.Add(c);
                continue;
            }

            if (line.Trim().StartsWith("END_IF", StringComparison.OrdinalIgnoreCase))
            {
                pending = null;
                continue;
            }
        }

        return constraints;
    }

    private static ConstraintOp ParseOp(string s) => s switch
    {
        ">" => ConstraintOp.GreaterThan,
        ">=" => ConstraintOp.GreaterOrEqual,
        "<" => ConstraintOp.LessThan,
        "<=" => ConstraintOp.LessOrEqual,
        "=" => ConstraintOp.Equal,
        "<>" => ConstraintOp.NotEqual,
        _ => ConstraintOp.Equal
    };
}
