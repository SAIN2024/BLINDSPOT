using System.Text.Json;
using System.Text.RegularExpressions;
using Blindspot.Core.Interfaces;
using Blindspot.Core.Models;
using Blindspot.Core.Utils;

namespace Blindspot.ConstraintExtraction;

/// <summary>
/// Starter extractor:
///  - ST/SCL: IF <cond> THEN <act>;
///  - Operator rules: JSON array of {id, cond, act}
/// Replace with a real IEC 61131-3 ST parser for full coverage.
/// </summary>
public sealed class SimpleConstraintExtractor : IConstraintExtractor
{
    private static readonly Regex IfThen =
        new(@"IF\s+(?<cond>.+?)\s+THEN\s+(?<act>.+?);",
            RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.Compiled);

    public Task<MultiLayerConstraintModel> ExtractAsync(ConstraintInputs inputs, CancellationToken ct)
    {
        var constraints = new Dictionary<string, Constraint>(StringComparer.OrdinalIgnoreCase);

        ExtractFromProgram(inputs.PlcProgramText, ConstraintLayer.Plc, "PLC", constraints);
        ExtractFromProgram(inputs.EsdProgramText, ConstraintLayer.Esd, "ESD", constraints);
        ExtractFromOperatorRules(inputs.OperatorRulesJson, constraints);

        var edges = BuildInitialMcmEdges(constraints);
        return Task.FromResult(new MultiLayerConstraintModel(constraints, edges));
    }

    private static void ExtractFromProgram(string text, ConstraintLayer layer, string prefix, Dictionary<string, Constraint> into)
    {
        int i = 0;
        foreach (Match m in IfThen.Matches(text))
        {
            i++;
            var cond = Normalize(m.Groups["cond"].Value);
            var act  = Normalize(m.Groups["act"].Value);

            var condVars = Expr.GuessVars(cond);
            var actVars  = Expr.GuessVars(act);

            var id = $"{prefix}_{i}";
            into[id] = new Constraint(
                Id: id,
                Layer: layer,
                When: new Condition(cond, condVars),
                Enforce: new ActionSpec(act, actVars),
                RegulatedVars: condVars.Concat(actVars).Distinct(StringComparer.OrdinalIgnoreCase).ToList()
            );
        }
    }

    private static void ExtractFromOperatorRules(string json, Dictionary<string, Constraint> into)
    {
        var doc = JsonDocument.Parse(json);
        int i = 0;
        foreach (var el in doc.RootElement.EnumerateArray())
        {
            i++;
            var id = el.TryGetProperty("id", out var idEl) ? idEl.GetString() : $"OP_{i}";
            id ??= $"OP_{i}";

            var cond = Normalize(el.GetProperty("cond").GetString() ?? "");
            var act  = Normalize(el.GetProperty("act").GetString() ?? "");

            var condVars = Expr.GuessVars(cond);
            var actVars  = Expr.GuessVars(act);

            into[id] = new Constraint(
                Id: id,
                Layer: ConstraintLayer.Operator,
                When: new Condition(cond, condVars),
                Enforce: new ActionSpec(act, actVars),
                RegulatedVars: condVars.Concat(actVars).Distinct(StringComparer.OrdinalIgnoreCase).ToList()
            );
        }
    }

    private static List<McmEdge> BuildInitialMcmEdges(Dictionary<string, Constraint> constraints)
    {
        // Simple MCM: connect constraints that touch the same variable in order of layer rank.
        var edges = new List<McmEdge>();

        var groups = constraints.Values
            .SelectMany(c => c.RegulatedVars.Select(v => (Var: v, C: c)))
            .GroupBy(x => x.Var, StringComparer.OrdinalIgnoreCase);

        foreach (var g in groups)
        {
            var ordered = g.Select(x => x.C)
                .DistinctBy(c => c.Id, StringComparer.OrdinalIgnoreCase)
                .OrderBy(c => LayerRank(c.Layer))
                .ThenBy(c => c.Id, StringComparer.OrdinalIgnoreCase)
                .ToList();

            for (int i = 0; i + 1 < ordered.Count; i++)
                edges.Add(new McmEdge(ordered[i].Id, ordered[i + 1].Id, "handoff"));
        }

        return edges;
    }

    private static int LayerRank(ConstraintLayer l) => l switch
    {
        ConstraintLayer.Plc => 0,
        ConstraintLayer.Operator => 1,
        ConstraintLayer.Esd => 2,
        _ => 99
    };

    private static string Normalize(string s) =>
        Regex.Replace(s.Trim(), @"\s+", " ");
}
