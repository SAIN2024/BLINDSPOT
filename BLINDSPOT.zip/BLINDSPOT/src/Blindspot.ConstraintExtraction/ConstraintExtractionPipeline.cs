using Blindspot.Core.Domain;
using Blindspot.ConstraintExtraction.Parsers;
using Blindspot.ConstraintExtraction.Model;

namespace Blindspot.ConstraintExtraction;

public sealed class ConstraintExtractionPipeline
{
    private readonly StProgramParser _st = new();
    private readonly GuidelineRuleParser _guides = new();
    private readonly McmBuilder _mcm = new();

    public (MultiLayerConstraintModel model, IReadOnlyList<Constraint> constraints) Run(
        string plcProgramText,
        string esdProgramText,
        string operatorGuidelinesJson)
    {
        var constraints = new List<Constraint>();

        constraints.AddRange(_st.Extract(plcProgramText, ConstraintLayer.Control, "CPLC"));
        constraints.AddRange(_guides.ExtractFromJson(operatorGuidelinesJson, "COP"));
        constraints.AddRange(_st.Extract(esdProgramText, ConstraintLayer.Safety, "CESD"));

        var model = _mcm.Build(constraints);
        return (model, constraints);
    }
}
