using System.Globalization;
using System.Text.RegularExpressions;

namespace Blindspot.Core.Utils;

/// <summary>
/// Minimal expression parsing utilities.
/// This implementation is intentionally conservative and deterministic.
/// Extend to full AST parsing if you need exact slack for composite boolean expressions.
/// </summary>
public static class Expr
{
    private static readonly Regex SimpleCmp =
        new(@"(?<var>[A-Za-z_][A-Za-z0-9_]*)\s*(?<op>>=|>|<=|<)\s*(?<num>-?\d+(\.\d+)?)",
            RegexOptions.Compiled | RegexOptions.CultureInvariant);

    public static (string Var, string Op, double Num)? TryParseSimpleComparison(string expr)
    {
        var m = SimpleCmp.Match(expr);
        if (!m.Success) return null;
        return (m.Groups["var"].Value,
                m.Groups["op"].Value,
                double.Parse(m.Groups["num"].Value, CultureInfo.InvariantCulture));
    }

    public static bool TryEvalTrigger(string triggerExpr, IReadOnlyDictionary<string,double> vars)
    {
        // Only supports "Var >= num" etc. If can't parse, return true (non-blocking).
        var p = TryParseSimpleComparison(triggerExpr);
        if (p is null) return TrueByDefault(triggerExpr);
        var (v, op, num) = p.Value;
        if (!vars.TryGetValue(v, out var val)) return false;
        return op switch
        {
            ">"  => val > num,
            ">=" => val >= num,
            "<"  => val < num,
            "<=" => val <= num,
            _ => false
        };
    }

    public static double SlackToBoundary(string condExpr, IReadOnlyDictionary<string,double> vars)
    {
        // Simple slack mapping:
        // Var >= b  => slack = b - Var  (negative => crossed)
        // Var <= b  => slack = Var - b
        var p = TryParseSimpleComparison(condExpr);
        if (p is null) return double.NaN;
        var (v, op, num) = p.Value;
        if (!vars.TryGetValue(v, out var val)) return double.NaN;
        return op switch
        {
            ">" or ">=" => num - val,
            "<" or "<=" => val - num,
            _ => double.NaN
        };
    }

    public static IReadOnlyList<string> GuessVars(string expr)
    {
        var toks = Regex.Matches(expr, @"[A-Za-z_][A-Za-z0-9_]*")
            .Select(m => m.Value)
            .Where(t => !IsKeyword(t))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
        return toks;
    }

    private static bool IsKeyword(string t) =>
        new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        { "IF","THEN","ELSE","END_IF","AND","OR","NOT","ABS","TRUE","FALSE" }.Contains(t);

    private static bool TrueByDefault(string expr)
    {
        // If expression is empty or "true", treat as true.
        if (string.IsNullOrWhiteSpace(expr)) return true;
        return expr.Trim().Equals("true", StringComparison.OrdinalIgnoreCase);
    }
}
