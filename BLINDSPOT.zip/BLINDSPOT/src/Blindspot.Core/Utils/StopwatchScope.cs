namespace Blindspot.Core.Utils;

public sealed class StopwatchScope : IDisposable
{
    private readonly System.Diagnostics.Stopwatch _sw = System.Diagnostics.Stopwatch.StartNew();
    private readonly Action<TimeSpan> _onDispose;

    public StopwatchScope(Action<TimeSpan> onDispose) => _onDispose = onDispose;

    public void Dispose()
    {
        _sw.Stop();
        _onDispose(_sw.Elapsed);
    }
}
