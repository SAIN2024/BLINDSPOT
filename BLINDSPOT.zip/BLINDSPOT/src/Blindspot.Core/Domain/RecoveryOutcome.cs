namespace Blindspot.Core.Domain;

public enum RecoveryOutcome
{
    Recoverable = 0,
    Infeasible = 1,
    Unsafe = 2
}

public sealed record RecoveryClassification(
    string TraceId,
    RecoveryOutcome Outcome,
    DateTimeOffset? DetectionTime,
    DateTimeOffset? RecoveryStartTime,
    DateTimeOffset? RecoveryCompleteTime,
    string? SupportingViolationConstraintId,
    string? Notes
);
