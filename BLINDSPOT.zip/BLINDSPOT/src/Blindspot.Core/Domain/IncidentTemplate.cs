namespace Blindspot.Core.Domain;

public sealed record TimeWindow(double StartSec, double EndSec)
{
    public override string ToString() => $"[{StartSec:0.###}s → {EndSec:0.###}s]";
}

public sealed record IncidentTemplate(
    string Id,
    string Goal, // "Infeasible" | "Unsafe" | "Escalation"
    Condition Trigger,
    IReadOnlyList<string> Variables,
    IReadOnlyDictionary<string, double> DeltaByVar,
    TimeWindow Duration,
    double HorizonSec
)
{
    public override string ToString()
        => $"{Id}: {Goal} if {Trigger} then Δ({string.Join(",", Variables)}) for {Duration}, H={HorizonSec}s";
}
