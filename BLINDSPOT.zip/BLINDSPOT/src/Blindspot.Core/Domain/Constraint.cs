namespace Blindspot.Core.Domain;

public enum ConstraintLayer
{
    Control = 0,
    Operator = 1,
    Safety = 2
}

public enum ConstraintOp
{
    GreaterThan,
    GreaterOrEqual,
    LessThan,
    LessOrEqual,
    Equal,
    NotEqual
}

public sealed record Condition(string Variable, ConstraintOp Op, double Threshold, string? Units = null)
{
    public bool Evaluate(IReadOnlyDictionary<string, double> state)
    {
        if (!state.TryGetValue(Variable, out var v)) return false;
        return Op switch
        {
            ConstraintOp.GreaterThan => v > Threshold,
            ConstraintOp.GreaterOrEqual => v >= Threshold,
            ConstraintOp.LessThan => v < Threshold,
            ConstraintOp.LessOrEqual => v <= Threshold,
            ConstraintOp.Equal => Math.Abs(v - Threshold) < 1e-9,
            ConstraintOp.NotEqual => Math.Abs(v - Threshold) >= 1e-9,
            _ => false
        };
    }

    public override string ToString()
    {
        var op = Op switch
        {
            ConstraintOp.GreaterThan => ">",
            ConstraintOp.GreaterOrEqual => ">=",
            ConstraintOp.LessThan => "<",
            ConstraintOp.LessOrEqual => "<=",
            ConstraintOp.Equal => "==",
            ConstraintOp.NotEqual => "!=",
            _ => "?"
        };
        return Units is null ? $"{Variable} {op} {Threshold}" : $"{Variable} {op} {Threshold} {Units}";
    }
}

public enum ActionKind
{
    RateLimit,
    Clamp,
    SetDiscrete
}

public sealed record EnforcementAction(ActionKind Kind, string TargetVariable, double Value, double? MaxRatePerSec = null, string? Units = null)
{
    public override string ToString()
    {
        return Kind switch
        {
            ActionKind.RateLimit => MaxRatePerSec is null
                ? $"RateLimit({TargetVariable},{Value})"
                : $"RateLimit({TargetVariable},|d/dt|<={MaxRatePerSec}{(Units is null ? "" : Units)})",
            ActionKind.Clamp => $"Clamp({TargetVariable},{Value}{(Units is null ? "" : Units)})",
            ActionKind.SetDiscrete => $"Set({TargetVariable}={Value})",
            _ => $"{Kind}({TargetVariable})"
        };
    }
}

public sealed record Constraint(
    string Id,
    ConstraintLayer Layer,
    Condition When,
    EnforcementAction Then,
    IReadOnlyList<string> RegulatedVariables,
    IReadOnlyList<string>? Tags = null
)
{
    public override string ToString()
        => $"{Id} [{Layer}] {When} => {Then}";
}
