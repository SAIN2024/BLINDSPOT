namespace Blindspot.Core.Domain;

public sealed record TracePoint(
    DateTimeOffset Timestamp,
    double TSec,
    IReadOnlyDictionary<string, double> Values,
    IReadOnlyDictionary<string, bool>? Flags = null
);

public sealed class ExecutionTrace
{
    public string TraceId { get; }
    public IReadOnlyList<TracePoint> Points { get; }
    public ExecutionTrace(string traceId, IReadOnlyList<TracePoint> points)
    {
        TraceId = traceId;
        Points = points;
    }

    public IEnumerable<string> Variables => Points.SelectMany(p => p.Values.Keys).Distinct(StringComparer.OrdinalIgnoreCase);

    public TracePoint? AtOrAfter(double tSec) => Points.FirstOrDefault(p => p.TSec >= tSec);
}
