namespace Blindspot.Core.Domain;

public sealed class MultiLayerConstraintModel
{
    public IReadOnlyList<Constraint> Constraints { get; }
    public IReadOnlyDictionary<string, IReadOnlyList<string>> EscalationEdges { get; }

    public MultiLayerConstraintModel(IReadOnlyList<Constraint> constraints, IReadOnlyDictionary<string, IReadOnlyList<string>> edges)
    {
        Constraints = constraints;
        EscalationEdges = edges;
    }

    public Constraint? GetById(string id) => Constraints.FirstOrDefault(c => c.Id.Equals(id, StringComparison.OrdinalIgnoreCase));

    public IEnumerable<Constraint> ByVariable(string varName)
        => Constraints.Where(c => c.RegulatedVariables.Any(v => v.Equals(varName, StringComparison.OrdinalIgnoreCase)));

    public IEnumerable<string> GetNext(string id)
        => EscalationEdges.TryGetValue(id, out var next) ? next : Array.Empty<string>();
}
