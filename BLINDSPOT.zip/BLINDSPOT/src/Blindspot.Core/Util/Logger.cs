namespace Blindspot.Core.Util;

public enum LogLevel { Trace, Debug, Info, Warn, Error }

public interface ILogger
{
    void Log(LogLevel level, string message);
    void Log(LogLevel level, string message, Exception ex);
}

public sealed class ConsoleLogger : ILogger
{
    private readonly LogLevel _min;
    public ConsoleLogger(LogLevel min) => _min = min;

    public void Log(LogLevel level, string message)
    {
        if (level < _min) return;
        var ts = DateTimeOffset.UtcNow.ToString("u");
        Console.WriteLine($"{ts} [{level}] {message}");
    }

    public void Log(LogLevel level, string message, Exception ex)
    {
        Log(level, $"{message}\n{ex}");
    }
}
