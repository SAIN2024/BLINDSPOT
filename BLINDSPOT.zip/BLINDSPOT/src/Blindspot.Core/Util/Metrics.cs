namespace Blindspot.Core.Util;

public sealed class Metrics
{
    private readonly Dictionary<string, long> _counters = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, List<double>> _samples = new(StringComparer.OrdinalIgnoreCase);

    public void Inc(string name, long by = 1)
    {
        _counters.TryGetValue(name, out var v);
        _counters[name] = v + by;
    }

    public void Observe(string name, double value)
    {
        if (!_samples.TryGetValue(name, out var list))
        {
            list = new List<double>();
            _samples[name] = list;
        }
        list.Add(value);
    }

    public IReadOnlyDictionary<string, long> Counters => _counters;
    public IReadOnlyDictionary<string, IReadOnlyList<double>> Samples => _samples.ToDictionary(k => k.Key, v => (IReadOnlyList<double>)v.Value);

    public string ToJson()
    {
        var obj = new
        {
            counters = _counters,
            samples = _samples.ToDictionary(k => k.Key, v => new { count = v.Value.Count, mean = v.Value.Count == 0 ? 0 : v.Value.Average(), min = v.Value.Count == 0 ? 0 : v.Value.Min(), max = v.Value.Count == 0 ? 0 : v.Value.Max() })
        };
        return JsonSerializer.Serialize(obj, new JsonSerializerOptions { WriteIndented = true });
    }
}
