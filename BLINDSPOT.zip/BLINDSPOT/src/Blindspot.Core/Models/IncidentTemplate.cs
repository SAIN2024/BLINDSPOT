namespace Blindspot.Core.Models;

// π = ⟨C, v, δ, τ, H⟩
public sealed record IncidentTemplate(
    string TemplateId,
    string TriggerCondition,
    IReadOnlyList<string> Variables,
    IReadOnlyDictionary<string, double> Delta,
    TimeWindow Timing,
    TimeSpan ObservationHorizon
);

public sealed record TimeWindow(TimeSpan StartOffset, TimeSpan EndOffset);
