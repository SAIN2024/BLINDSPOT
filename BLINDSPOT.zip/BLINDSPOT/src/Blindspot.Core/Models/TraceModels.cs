namespace Blindspot.Core.Models;

public sealed record TracePoint(DateTime Ts, IReadOnlyDictionary<string, double> Vars);

public sealed record ExecutionTrace(
    string TraceId,
    IReadOnlyList<TracePoint> Points,
    IReadOnlyList<(string ConstraintId, DateTime Ts)> Violations,
    IReadOnlyDictionary<string, DateTime> Events
);
