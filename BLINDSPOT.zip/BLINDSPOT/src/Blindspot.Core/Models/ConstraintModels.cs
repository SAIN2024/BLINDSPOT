namespace Blindspot.Core.Models;

public enum ConstraintLayer { Plc, Operator, Esd }

public sealed record Condition(string Expr, IReadOnlyList<string> Vars);
public sealed record ActionSpec(string Expr, IReadOnlyList<string> Vars);

public sealed record Constraint(
    string Id,
    ConstraintLayer Layer,
    Condition When,
    ActionSpec Enforce,
    IReadOnlyList<string> RegulatedVars
);

public sealed record McmEdge(string FromId, string ToId, string Type);

public sealed record MultiLayerConstraintModel(
    IReadOnlyDictionary<string, Constraint> Constraints,
    IReadOnlyList<McmEdge> Edges
);
