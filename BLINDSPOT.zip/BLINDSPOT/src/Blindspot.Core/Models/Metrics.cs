namespace Blindspot.Core.Models;

public sealed record Metric(string Name, double Value, string Unit);

public sealed class MetricSink
{
    private readonly List<Metric> _metrics = new();
    public IReadOnlyList<Metric> Metrics => _metrics;

    public void Add(string name, double value, string unit = "")
        => _metrics.Add(new Metric(name, value, unit));
}
