using Blindspot.Core.Models;

namespace Blindspot.Core.Interfaces;

public sealed record ConstraintInputs(string PlcProgramText, string EsdProgramText, string OperatorRulesJson);

public interface IConstraintExtractor
{
    Task<MultiLayerConstraintModel> ExtractAsync(ConstraintInputs inputs, CancellationToken ct);
}

public sealed record SlackStats(double TypicalEscalationRatePerSec,
                                double TypicalRecoveryRatePerSec,
                                double TypicalMinSlack,
                                double TypicalTimeToConstraintSec);

public sealed record CouplingStats(IReadOnlyList<string> OftenCoActivatedConstraintIds);

public sealed record ConstraintPatterns(IReadOnlyDictionary<string, SlackStats> SlackByConstraint,
                                       IReadOnlyDictionary<string, CouplingStats> Coupling);

public interface ITraceAnalyzer
{
    Task<ConstraintPatterns> AnalyzeAsync(MultiLayerConstraintModel mcm, IReadOnlyList<TracePoint> trace, CancellationToken ct);
}

public sealed record ManipulableSurface(IReadOnlyList<string> WritableVars,
                                       IReadOnlyDictionary<string, (double Min, double Max)> DeltaBounds,
                                       IReadOnlyDictionary<string, (double MinSec, double MaxSec)> DurationBoundsSec);

public interface ITemplateGenerator
{
    Task<IReadOnlyList<IncidentTemplate>> ProposeTemplatesAsync(MultiLayerConstraintModel mcm,
                                                                ConstraintPatterns patterns,
                                                                ManipulableSurface surface,
                                                                CancellationToken ct);
}

public interface ITemplateValidator
{
    IReadOnlyList<IncidentTemplate> ValidateAndInstantiate(IReadOnlyList<IncidentTemplate> proposed,
                                                          MultiLayerConstraintModel mcm,
                                                          ConstraintPatterns patterns,
                                                          ManipulableSurface surface);
}

public interface IPlcExecutor
{
    Task<ExecutionTrace> ExecuteAsync(MultiLayerConstraintModel mcm,
                                     IncidentTemplate template,
                                     IReadOnlyList<TracePoint> baselineTrace,
                                     CancellationToken ct);
}
