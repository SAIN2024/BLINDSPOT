namespace Blindspot.Core.Diagnostics;

public enum LogLevel { Trace, Debug, Info, Warn, Error }

public interface ILogger
{
    void Write(LogLevel level, string message);
    void Write(LogLevel level, string message, Exception ex);
}

public sealed class ConsoleLogger : ILogger
{
    private readonly object _lock = new();
    private readonly LogLevel _min;

    public ConsoleLogger(LogLevel min = LogLevel.Info) => _min = min;

    public void Write(LogLevel level, string message)
    {
        if (level < _min) return;
        lock (_lock)
        {
            var ts = DateTime.UtcNow.ToString("o");
            Console.WriteLine($"[{ts}] {level}: {message}");
        }
    }

    public void Write(LogLevel level, string message, Exception ex)
    {
        Write(level, $"{message} :: {ex.GetType().Name}: {ex.Message}\n{ex.StackTrace}");
    }
}

public static class Log
{
    public static ILogger Current { get; set; } = new ConsoleLogger(LogLevel.Info);
    public static void Trace(string m) => Current.Write(LogLevel.Trace, m);
    public static void Debug(string m) => Current.Write(LogLevel.Debug, m);
    public static void Info(string m)  => Current.Write(LogLevel.Info,  m);
    public static void Warn(string m)  => Current.Write(LogLevel.Warn,  m);
    public static void Error(string m, Exception? ex = null)
    {
        if (ex is null) Current.Write(LogLevel.Error, m);
        else Current.Write(LogLevel.Error, m, ex);
    }
}
