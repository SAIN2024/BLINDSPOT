using Blindspot.Core.Util;
using Blindspot.ConstraintExtraction;
using Blindspot.TraceAnalysis.IO;
using Blindspot.TraceAnalysis.Patterns;
using Blindspot.TemplateGen;
using Blindspot.Execution;
using Blindspot.RecoveryAnalysis;
using Blindspot.Reporting;

static class Program
{
    static int Main(string[] args)
    {
        var parsed = Args.Parse(args);
        var logger = new ConsoleLogger(parsed.LogLevel);

        try
        {
            logger.Log(LogLevel.Info, "BLINDSPOT pipeline starting...");

            var plcText = File.ReadAllText(Path.Combine(parsed.SampleRoot, "plc.st"));
            var esdText = File.ReadAllText(Path.Combine(parsed.SampleRoot, "esd.st"));
            var opJson = File.ReadAllText(Path.Combine(parsed.SampleRoot, "operator.json"));

            var extractor = new ConstraintExtractionPipeline();
            var (mcm, constraints) = extractor.Run(plcText, esdText, opJson);

            logger.Log(LogLevel.Info, $"Constraints extracted: {constraints.Count}");

            var traceReader = new CsvTraceReader();
            var traces = Directory.GetFiles(Path.Combine(parsed.SampleRoot, "traces"), "*.csv")
                .Select((p, i) => traceReader.Read($"trace_{i+1:000}", p))
                .ToList();

            logger.Log(LogLevel.Info, $"Traces loaded: {traces.Count}");

            var patternExtractor = new PatternExtractor();
            var patterns = patternExtractor.Extract(mcm, traces);
            logger.Log(LogLevel.Info, $"Patterns extracted: {patterns.ByConstraint.Count}");

            ITemplateProposer proposer = BuildProposer(parsed, logger);
            var templates = proposer.Propose(mcm, patterns, new ProposalOptions(parsed.MaxTemplates, parsed.Goal, parsed.Seed, parsed.HorizonSec));
            logger.Log(LogLevel.Info, $"Templates proposed: {templates.Count}");

            var exec = new VirtualPlcBackend();
            var screen = new PreScreening();
            var analyzer = new RecoveryAnalyzer();
            var report = new ReportWriter();

            Directory.CreateDirectory(parsed.OutDir);

            var classifications = new List<object>();

            int runNo = 0;
            foreach (var tpl in templates)
            {
                runNo++;
                var req = new ExecutionRequest($"run_{runNo:0000}", tpl, mcm, parsed.Scenario, parsed.StepSec);
                var res = exec.Execute(req);

                if (!screen.Accept(res.Trace, mcm, out var reject))
                {
                    logger.Log(LogLevel.Debug, $"{req.RunId} rejected: {reject}");
                    continue;
                }

                var cls = analyzer.Classify(res.Trace, mcm);
                logger.Log(LogLevel.Info, $"{req.RunId} => {cls.Outcome}");

                report.WriteCsv(parsed.OutDir, res.Trace, $"{req.RunId}.csv");

                classifications.Add(new
                {
                    runId = req.RunId,
                    template = tpl,
                    outcome = cls
                });
            }

            report.WriteJson(parsed.OutDir, new
            {
                scenario = parsed.Scenario,
                goal = parsed.Goal,
                maxTemplates = parsed.MaxTemplates,
                results = classifications
            }, "report.json");

            report.WriteGraphviz(parsed.OutDir, mcm, "mcm.dot");

            logger.Log(LogLevel.Info, $"Done. Outputs in {parsed.OutDir}");
            return 0;
        }
        catch (Exception ex)
        {
            logger.Log(LogLevel.Error, "Pipeline failed.", ex);
            return 2;
        }
    }

    private static ITemplateProposer BuildProposer(Args.Parsed parsed, ILogger logger)
    {
        if (parsed.UseChatProvider)
        {
            var key = Environment.GetEnvironmentVariable("OPENAI_API_KEY");
            if (string.IsNullOrWhiteSpace(key))
            {
                logger.Log(LogLevel.Warn, "OPENAI_API_KEY not set; using deterministic proposer.");
                return new DeterministicTemplateProposer();
            }

            var model = Environment.GetEnvironmentVariable("OPENAI_MODEL");
            var baseUrl = Environment.GetEnvironmentVariable("OPENAI_BASE_URL");

            var http = new HttpClient();
            var chat = new OpenAiChatClient(http, key, model, baseUrl);
            logger.Log(LogLevel.Info, "Using external chat provider proposer.");
            return new ChatTemplateProposer(chat);
        }

        return new DeterministicTemplateProposer();
    }
}

file static class Args
{
    public sealed record Parsed(
        string SampleRoot,
        string OutDir,
        string Scenario,
        string Goal,
        int MaxTemplates,
        int Seed,
        double HorizonSec,
        double StepSec,
        bool UseChatProvider,
        LogLevel LogLevel
    );

    public static Parsed Parse(string[] args)
    {
        string Get(string k, string def)
        {
            for (int i = 0; i < args.Length - 1; i++)
                if (args[i] == $"--{k}") return args[i + 1];
            return def;
        }
        bool Has(string k) => args.Any(a => a == $"--{k}");

        var sampleRoot = Get("sampleRoot", "samples/water");
        var outDir = Get("outDir", "out");
        var scenario = Get("scenario", "water");
        var goal = Get("goal", "Infeasible");
        var maxT = int.Parse(Get("maxTemplates", "30"), CultureInfo.InvariantCulture);
        var seed = int.Parse(Get("seed", "7"), CultureInfo.InvariantCulture);
        var horizon = double.Parse(Get("horizonSec", "30"), CultureInfo.InvariantCulture);
        var step = double.Parse(Get("stepSec", "0.2"), CultureInfo.InvariantCulture);
        var useChat = Has("useChatProvider");
        var log = Enum.TryParse<LogLevel>(Get("log", "Info"), true, out var lvl) ? lvl : LogLevel.Info;

        return new Parsed(sampleRoot, outDir, scenario, goal, maxT, seed, horizon, step, useChat, log);
    }
}
