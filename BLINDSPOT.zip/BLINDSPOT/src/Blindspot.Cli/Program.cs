using System.Text.Json;
using Blindspot.ConstraintExtraction;
using Blindspot.Core.Diagnostics;
using Blindspot.Core.Interfaces;
using Blindspot.Core.Models;
using Blindspot.Core.Utils;
using Blindspot.Execution;
using Blindspot.RecoveryAnalysis;
using Blindspot.Report;
using Blindspot.TemplateGen;
using Blindspot.TraceAnalysis;

static string? GetArg(string[] args, string name)
{
    var i = Array.FindIndex(args, a => a.Equals(name, StringComparison.OrdinalIgnoreCase));
    if (i >= 0 && i + 1 < args.Length) return args[i + 1];
    return null;
}
static bool HasFlag(string[] args, string name) =>
    args.Any(a => a.Equals(name, StringComparison.OrdinalIgnoreCase));

var sampleRoot = GetArg(args, "--sampleRoot") ?? "samples/water";
var useMockLlm = bool.TryParse(GetArg(args, "--useMockLlm") ?? "true", out var ml) ? ml : true;
var outDir = GetArg(args, "--outDir") ?? "out";
var logLevel = GetArg(args, "--log") ?? "info";

Log.Current = new ConsoleLogger(logLevel.ToLowerInvariant() switch
{
    "trace" => LogLevel.Trace,
    "debug" => LogLevel.Debug,
    "warn"  => LogLevel.Warn,
    "error" => LogLevel.Error,
    _       => LogLevel.Info
});

Directory.CreateDirectory(outDir);

string plc = File.ReadAllText(Path.Combine(sampleRoot, "plc.st"));
string esd = File.ReadAllText(Path.Combine(sampleRoot, "esd.st"));
string op  = File.ReadAllText(Path.Combine(sampleRoot, "operator_rules.json"));
var trace  = CsvTraceLoader.Load(Path.Combine(sampleRoot, "trace.csv"));

var surface = JsonSerializer.Deserialize<ManipulableSurface>(
    File.ReadAllText(Path.Combine(sampleRoot, "manipulable.json")),
    new JsonSerializerOptions { PropertyNameCaseInsensitive = true })
    ?? throw new InvalidOperationException("manipulable.json invalid.");

IConstraintExtractor extractor = new SimpleConstraintExtractor();
ITraceAnalyzer analyzer = new SlackTraceAnalyzer();
ITemplateValidator validator = new TemplateValidator();
IPlcExecutor executor = new MockPlcExecutor();
MetricSink metrics = new();

ITemplateGenerator tgen = new SchemaTemplateGenerator(new MockChatClient());
if (!useMockLlm)
{
    // Hook your OpenAI-compatible client here if desired.
    Log.Warn("Non-mock LLM mode not wired in this offline-safe reference build. Using mock.");
}

MultiLayerConstraintModel mcm;
ConstraintPatterns patterns;
IReadOnlyList<IncidentTemplate> proposed;
IReadOnlyList<IncidentTemplate> templates;

using (new StopwatchScope(ts => metrics.Add("extract_constraints_ms", ts.TotalMilliseconds, "ms")))
    mcm = await extractor.ExtractAsync(new(plc, esd, op), CancellationToken.None);

using (new StopwatchScope(ts => metrics.Add("trace_analysis_ms", ts.TotalMilliseconds, "ms")))
    patterns = await analyzer.AnalyzeAsync(mcm, trace, CancellationToken.None);

using (new StopwatchScope(ts => metrics.Add("template_proposal_ms", ts.TotalMilliseconds, "ms")))
    proposed = await tgen.ProposeTemplatesAsync(mcm, patterns, surface, CancellationToken.None);

using (new StopwatchScope(ts => metrics.Add("template_validation_ms", ts.TotalMilliseconds, "ms")))
    templates = validator.ValidateAndInstantiate(proposed, mcm, patterns, surface);

Log.Info($"Constraints: {mcm.Constraints.Count}, Edges: {mcm.Edges.Count}");
Log.Info($"Templates proposed: {proposed.Count}, valid: {templates.Count}");

GraphvizExporter.WriteDot(Path.Combine(outDir, "mcm.dot"), mcm);

var classifier = new RecoveryClassifier();
var results = new List<RecoveryResult>();

using (new StopwatchScope(ts => metrics.Add("execution_and_classification_ms", ts.TotalMilliseconds, "ms")))
{
    foreach (var t in templates)
    {
        var execTrace = await executor.ExecuteAsync(mcm, t, trace, CancellationToken.None);
        var res = classifier.Classify(mcm, execTrace);
        results.Add(res);
        Log.Info($"{t.TemplateId} => {res.Outcome}");
    }
}

var meta = new {
    sampleRoot,
    whenUtc = DateTime.UtcNow,
    constraints = mcm.Constraints.Count,
    edges = mcm.Edges.Count,
    templatesProposed = proposed.Count,
    templatesValid = templates.Count
};

ReportWriter.WriteJson(Path.Combine(outDir, "blindspot_report.json"), results, meta, metrics);
ReportWriter.WriteCsv(Path.Combine(outDir, "blindspot_report.csv"), results);

Log.Info($"Wrote reports to: {Path.GetFullPath(outDir)}");
Log.Info("DOT graph: out/mcm.dot (render with: dot -Tpng mcm.dot -o mcm.png)");
