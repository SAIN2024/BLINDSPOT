# BLINDSPOT (C#/.NET 8)

This repository provides a full, runnable implementation of the BLINDSPOT pipeline described in the paper:
- multi-layer constraint modeling
- constraint-centric pattern extraction
- unanticipated incident template generation
- virtual PLC execution for scalable screening
- recovery feasibility and safety classification

The pipeline corresponds to the components listed in the paper’s Open Science section: static constraint extraction, trace analysis, incident generation, virtual execution, and recovery analysis. fileciteturn3file2L36-L44

## Quickstart

```bash
dotnet build BLINDSPOT.sln
dotnet run --project src/Blindspot.Cli -- --sampleRoot samples/water --scenario water --goal Infeasible --outDir out --log Info
```

Outputs:
- `out/report.json` summary
- `out/run_XXXX.csv` execution traces
- `out/mcm.dot` Multi-layer constraint model graph (Graphviz)

## External chat provider (optional)

If you want to use a chat model to propose templates under a strict schema (Sec 7.3), set:

- `OPENAI_API_KEY`
- `OPENAI_MODEL` (optional)
- `OPENAI_BASE_URL` (optional)

Then add `--useChatProvider` to the CLI.

## Notes on portability

The virtual execution backend is designed as an adapter (`IPlcExecutionBackend`). In a lab environment you can replace it with a vendor simulator or soft-PLC integration while keeping the rest of the pipeline unchanged. fileciteturn3file0L16-L27
